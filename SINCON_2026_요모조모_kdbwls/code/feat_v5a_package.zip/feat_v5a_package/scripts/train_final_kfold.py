"""최종 학습: 직접 모델(R0 피처, 목표 y_dev) 역 층화 5겹 평균 x 시드, 선택적으로 LGBM B 가중 합

사용법: python train_final_kfold.py <피처 폴더> <출력 폴더> <test.csv> [시드 수=3] [LGBM B 가중치=0]
"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedKFold

sys.path.insert(0, str(Path(__file__).parent))
from dlib import feature_sets_for, fit_lgb, load  # noqa: E402

F, OUT, TEST = Path(sys.argv[1]), Path(sys.argv[2]), sys.argv[3]
NS = int(sys.argv[4]) if len(sys.argv) > 4 else 3
WB = float(sys.argv[5]) if len(sys.argv) > 5 else 0.0
WC = float(sys.argv[6]) if len(sys.argv) > 6 else 0.0
OUT.mkdir(parents=True, exist_ok=True)
d, meta = load(F, "final")
feats, cats = feature_sets_for(meta, "dev")["FS5_전체"], meta["categorical"]
tr, te = d[(d.is_target == 0) & d.y_dev.notna()], d[d.is_target == 1].reset_index(drop=True)
print("train", len(tr), "target", len(te), "feats", len(feats), flush=True)
acc = np.zeros(len(te))
for seed in range(NS):
    skf = StratifiedKFold(5, shuffle=True, random_state=seed)
    for i, (a, _) in enumerate(skf.split(tr, tr.station_id.astype(int))):
        acc += fit_lgb(tr.iloc[a], te, feats, cats, "dev", seeds=(42 + seed,))
        print("seed", seed, "fold", i, flush=True)
p = acc / (5 * NS)
np.save(OUT / "final_kfold.npy", p)
if WB > 0:
    G = meta["groups"]
    fb = [c for c in feats if c not in G["날씨2"] + G["계절(노이즈역)"]]
    pb = fit_lgb(tr, te, fb, cats, "dev", params=dict(num_leaves=63, extra_trees=True, feature_fraction=0.6, min_data_in_leaf=60),
                 rounds=900, seeds=(42, 43, 44))
    np.save(OUT / "final_lgbmB.npy", pb)
if WC > 0:
    from catboost import CatBoostRegressor, Pool
    cc = [c for c in cats if c in feats]

    def cbf(df):
        x = df[feats].copy()
        for c in cc:
            x[c] = x[c].astype(object).where(x[c].notna(), "NA").astype(str)
        return x
    cb = CatBoostRegressor(iterations=1000, learning_rate=0.1, depth=8, loss_function="RMSE", random_seed=0, thread_count=-1,
                           verbose=0, border_count=128, one_hot_max_size=4)
    cb.fit(Pool(cbf(tr), tr.y_dev.to_numpy(), cat_features=cc, weight=tr.w.to_numpy()))
    pc = np.clip(te.base.to_numpy() + cb.predict(Pool(cbf(te), cat_features=cc)), 0, None)
    np.save(OUT / "final_catboost.npy", pc)
np.save(OUT / "final_kfold_only.npy", p)
subs = [("", p)]
if WB > 0 or WC > 0:
    subs.append((f"_lgbmB{WB:g}_cat{WC:g}", (1 - WB - WC) * p + (WB * pb if WB > 0 else 0) + (WC * pc if WC > 0 else 0)))
test = pd.read_csv(TEST)
for tag, q in subs:
    sub = test[["example_id"]].merge(te[["example_id"]].assign(boardings=np.expm1(q)), on="example_id", how="left")
    assert len(sub) == 157194 and sub.boardings.notna().all() and np.isfinite(sub.boardings).all() and (sub.boardings >= 0).all()
    name = f"submission_new_kfold5x{NS}{tag}.csv"
    sub.to_csv(OUT / name, index=False)
    print(name, round(sub.boardings.mean(), 2), len(sub), flush=True)
