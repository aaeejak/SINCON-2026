"""SINCON 2026 - 팀이 검증·통합한 추가 데이터(2026-11-12)로 외부 자료 교체

사용법: python build_external_v2.py <통합 자료 폴더> <기존 ext_clean> <KBO 박스스코어 csv> <출력 폴더>

바꾸는 것
  calendar_daily.csv    공휴일을 통합 달력(derived/calendar_features.csv) 기준으로 (2025-05-01 근로자의날 = 휴일)
                        2026-07-17 제헌절 공휴일, 2026-09-28 평일은 기존과 같음
  events.csv            통합 행사 목록 external/events_master.csv (검증된 275건)만 사용
                        - SSG 정규·포스트시즌·시범경기(bb_pre)·취소 경기(bb_cancel), 부천FC, 공연, 축제
                        - SSG 실제 개시·종료 시각과 관중은 KBO 게임센터 박스스코어(공식)에서 붙임
                        - 관중 수는 공식 기록만 사용 (K리그 official, KBO 박스스코어). 공연·축제 추정치는 안 씀
                        - 미검증 목록(events_reference_unverified.csv)의 계양아라온 워터축제·부평풍물대축제 등은 뺌
  events_hourly.csv     위 목록으로 다시 펼침. 취소 경기는 예정 시각 앞뒤 1시간을 '귀가'로 표시 (모였다가 흩어짐)
  geomdan_station_daily 검단 아파트 입주 일정은 통합 자료에서 제외됨 → 0으로 (인구 통계만 사용)
그대로 쓰는 것 (통합 자료와 값이 같음을 확인): 날씨, 방학, 인천대 학기, 검단 인구, 역 정보, 월보 2023·2024, 운영 시각표
"""
import shutil
import sys
from pathlib import Path

import numpy as np
import pandas as pd

IN, OLD, KBO, OUT = map(Path, sys.argv[1:5])
OUT.mkdir(parents=True, exist_ok=True)
HOURS = list(range(6, 24))
for f in ["weather_hourly", "station_static", "ops_hourly", "past_monthly_boardings", "holidays"]:
    shutil.copy(OLD / f"{f}.csv", OUT / f"{f}.csv")
issues = []

# ---------------------------------------------------------------- 달력
cal = pd.read_csv(OLD / "calendar_daily.csv", encoding="utf-8-sig", parse_dates=["date"])
nc = pd.read_csv(IN / "derived/calendar_features.csv", encoding="utf-8-sig", parse_dates=["date"])
nc = nc.set_index("date")
diff = cal[cal.is_holiday.to_numpy() != nc.loc[cal.date, "is_holiday"].to_numpy()].date
for d in diff:
    cal.loc[cal.date == d, "is_holiday"] = int(nc.loc[d, "is_holiday"])
    cal.loc[cal.date == d, "holiday_name"] = nc.loc[d, "holiday_name"]
    issues.append(("달력", f"{d.date()} 공휴일 여부를 통합 달력 기준 {int(nc.loc[d, 'is_holiday'])}로"))
cal["is_offday"] = ((cal.is_weekend == 1) | (cal.is_holiday == 1)).astype(int)
# 연휴 블록·앞뒤 휴일 거리·징검다리 다시 계산
blk = (cal.is_offday != cal.is_offday.shift()).cumsum()
cal["offday_block_len"] = np.where(cal.is_offday == 1, cal.groupby(blk).is_offday.transform("size"), 0)
cal["offday_block_pos"] = np.where(cal.is_offday == 1, cal.groupby(blk).cumcount() + 1, 0)
off_dates = cal.loc[cal.is_offday == 1, "date"].to_numpy()
idx_next = np.searchsorted(off_dates, cal.date.to_numpy(), side="right")
idx_prev = np.searchsorted(off_dates, cal.date.to_numpy(), side="left") - 1
cal["days_to_next_offday"] = [((off_dates[i] - d) / np.timedelta64(1, "D")) if i < len(off_dates) else 7 for i, d in zip(idx_next, cal.date.to_numpy())]
cal["days_from_prev_offday"] = [((d - off_dates[i]) / np.timedelta64(1, "D")) if i >= 0 else 7 for i, d in zip(idx_prev, cal.date.to_numpy())]
cal[["days_to_next_offday", "days_from_prev_offday"]] = cal[["days_to_next_offday", "days_from_prev_offday"]].clip(upper=7).astype(int)
cal["is_bridge_day"] = ((cal.is_offday == 0) & (cal.days_to_next_offday == 1) & (cal.days_from_prev_offday == 1)).astype(int)
cal["is_long_holiday"] = (cal.offday_block_len >= 3).astype(int)
# 통합 달력과 같은지 확인 (공휴일·휴일·방학·학기·날씨)
chk = nc.loc[cal.date]
assert (cal.is_holiday.to_numpy() == chk.is_holiday.to_numpy()).all()
assert (cal.is_offday.to_numpy() == chk.is_offday.to_numpy()).all()
assert (cal.univ_semester.to_numpy() == chk.univ_semester.to_numpy()).all()
assert np.allclose(cal.vac_all.to_numpy(), chk.vac_all.to_numpy())
assert np.allclose(cal.precip_day.to_numpy(), chk.precip_day_mm.to_numpy())
cal.to_csv(OUT / "calendar_daily.csv", index=False, encoding="utf-8-sig")

# ---------------------------------------------------------------- 행사
em = pd.read_csv(IN / "external/events_master.csv", encoding="utf-8-sig")
kr = pd.read_csv(KBO, dtype=str, encoding="utf-8-sig")
kr["d"] = kr.date.str[:4] + "-" + kr.date.str[4:6] + "-" + kr.date.str[6:]


def hm(x):
    if pd.isna(x) or not str(x).strip():
        return np.nan
    h, m = str(x).split(":")
    return int(h) + int(m) / 60


kr["start_h"], kr["end_h"] = kr.start_tm.map(hm), kr.end_tm.map(hm)
kr["crowd"] = pd.to_numeric(kr.crowd, errors="coerce")
kr["played"] = (kr.cancel == "정상경기").astype(int)
kb = kr.groupby("d").apply(lambda g: pd.Series(dict(
    k_start=g[g.played == 1].start_h.min(), k_end=g[g.played == 1].end_h.max(), k_crowd=g[g.played == 1].crowd.sum(min_count=1),
    k_n=int(g.played.sum()), k_type=g.game_type.iloc[0])), include_groups=False)
rows = []
for r in em.itertuples():
    k = r.ev_key
    base = dict(date=r.date, station_id=int(r.station_id), name=r.event_name, start_hour=r.ev_start, end_hour=np.nan,
                attendance=np.nan, played=1, n_games=0, is_exhibition=0, source=r.source, note=str(r.verification))
    if k.startswith("bb"):
        g = kb.loc[r.date] if r.date in kb.index else None
        if k == "bb_cancel":
            base.update(kind="kbo_cancel", code="kbo_cancel", scale=1)
        else:
            pre = k == "bb_pre"
            base.update(kind="kbo", code="kbo", scale=1 if pre else 3 if (g is not None and "PO" in str(g.k_type)) else 2, is_exhibition=int(pre))
            if g is not None and g.k_n > 0:
                base.update(start_hour=g.k_start, end_hour=g.k_end, attendance=g.k_crowd, n_games=int(g.k_n))
            else:
                issues.append(("SSG", f"{r.date} 경기 목록에 있지만 박스스코어에 정상 경기 없음"))
    elif k.startswith("fc"):
        base.update(kind="kleague", code="kleague", scale=1, end_hour=r.ev_start + 2,
                    attendance=r.ev_att if r.ev_att_basis == "official" else np.nan)
    elif k == "concert":
        base.update(kind="concert", code=r.event_name, scale=3)
    elif k == "pentaport":
        base.update(kind="fest", code="pentaport", scale=3, end_hour=21.0)
    elif k == "beer":
        base.update(kind="fest", code="beerfest", scale=2, end_hour=21.0)
    else:
        base.update(kind="fest", code=r.event_name, scale=2, end_hour=21.0)
    rows.append(base)
ev = pd.DataFrame(rows)
ev["date"] = pd.to_datetime(ev.date)
ev["date_status"], ev["source_grade"], ev["use_default"], ev["origin"] = "confirmed", "official", 1, "events_master"
ev["train_effect"] = np.nan
# 같은 날 같은 역 같은 code 중복 제거 (문학 더블헤더 등)
ev = ev.sort_values(["date", "station_id", "kind"]).drop_duplicates(["date", "station_id", "code"]).reset_index(drop=True)
assert set(kb[kb.k_n > 0].index) <= set(ev[ev.kind == "kbo"].date.dt.strftime("%Y-%m-%d")), "박스스코어 정상 경기가 목록에 없음"
cols = ["date", "station_id", "kind", "code", "name", "start_hour", "end_hour", "scale", "attendance", "played", "n_games", "is_exhibition",
        "date_status", "source_grade", "use_default", "train_effect", "origin", "source", "note"]
ev[cols].to_csv(OUT / "events.csv", index=False, encoding="utf-8-sig")
old = pd.read_csv(OLD / "events.csv", encoding="utf-8-sig", parse_dates=["date"])
old = old[old.use_default == 1]
ok, nk = set(zip(old.date, old.station_id)), set(zip(ev.date, ev.station_id))
issues.append(("행사", f"기존 사용 {len(ok)}개(날짜·역) → 통합 {len(nk)}개. 빠진 것 {len(ok - nk)}개(아라온 워터축제·부평풍물·원미산 진달래), "
                     f"새로 들어온 것 {len(nk - ok)}개(SSG 취소 경기 17일 중 다른 행사 없는 날)"))

# 시간대 펼치기 (기존 규칙 + 취소 경기)
offday_set = set(cal.loc[cal.is_offday == 1, "date"])
DUR = {"kbo": 3.25, "kleague": 2.0, "concert": 3.5}
hr = []
for r in ev.itertuples():
    off = r.date in offday_set
    s0 = r.start_hour if not pd.isna(r.start_hour) else {"kbo": 18.5, "kleague": 19.0, "concert": 18.0 if off else 19.0, "fest": 11.0,
                                                         "kbo_cancel": 18.5}[r.kind]
    if r.kind == "kbo_cancel":
        for h in (int(np.floor(s0)) - 1, int(np.floor(s0)), int(np.floor(s0)) + 1):
            if h in HOURS:
                hr.append((r.date, r.station_id, h, r.kind, 0, 1, 1))
        continue
    e0 = r.end_hour if not pd.isna(r.end_hour) else (s0 + DUR[r.kind] if r.kind in DUR else 21.0)
    for h in range(int(np.floor(s0)) - 1, int(np.floor(e0))):
        if h in HOURS:
            hr.append((r.date, r.station_id, h, r.kind, 1, 0, 1))
    for h in (int(np.floor(e0)), int(np.floor(e0)) + 1):
        if h in HOURS:
            hr.append((r.date, r.station_id, h, r.kind, 0, 1, 1))
eh = pd.DataFrame(hr, columns=["date", "station_id", "hour", "kind", "evt_on", "evt_exit", "use_default"])
eh = eh.groupby(["date", "station_id", "hour", "kind"]).max().reset_index()
eh.to_csv(OUT / "events_hourly.csv", index=False, encoding="utf-8-sig")

# ---------------------------------------------------------------- 검단 입주 일정 제외
gd = pd.read_csv(OLD / "geomdan_station_daily.csv", encoding="utf-8-sig")
gd[["movein_units_cum", "movein_units_cum_confirmed"]] = 0.0
gd.to_csv(OUT / "geomdan_station_daily.csv", index=False, encoding="utf-8-sig")
issues.append(("검단 입주", "통합 자료에서 아파트 입주 일정이 빠짐(블로그 출처)", "movein 열을 0으로, 검단 인구(행정안전부)만 사용"))

di = pd.read_csv(OLD / "data_issues.csv", encoding="utf-8-sig")
pd.concat([di, pd.DataFrame([(i[0], i[1], i[2] if len(i) > 2 else "통합 자료 기준") for i in issues], columns=["area", "problem", "action"])]).to_csv(
    OUT / "data_issues.csv", index=False, encoding="utf-8-sig")
for i in issues:
    print(" | ".join(i))
print(ev.kind.value_counts().to_dict(), "시간 행", len(eh))
