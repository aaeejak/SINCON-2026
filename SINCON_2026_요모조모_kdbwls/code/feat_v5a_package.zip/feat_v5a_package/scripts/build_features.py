"""SINCON 2026 - 새 모델 피처 생성 (기준일별, 누출 없음)

사용법: python build_features.py <combined_ext.parquet> <출력 폴더> [A B final]
  A     : 기준일 2025-06-30, 예측 2025-07-01~10-31 (검증, 정답 있음)
  B     : 기준일 2026-02-28, 예측 2026-03-01~06-30 (검증, 정답 있음)
  final : 기준일 2026-06-30, 예측 2026-07-01~10-31 (제출)

원칙
- 승차로 계산하는 값(역 수준·추세·공휴일 반응·행사 효과·군집)은 모두 기준일 이전 기록만 사용
- 예측 행에서 쓰는 지연값은 기준일을 넘지 않게: 123일 지연(10/31-123=6/30), 364일 지연(작년 같은 시기)
- 행사·명절처럼 날짜 수가 적은 효과 평균은 학습 행에서 자기 날짜를 뺀 값 (자기 정답이 피처에 새지 않게)
- 학습 목표 추천: y_dev = log1p(boardings) - base  (base = 역·시간·요일유형 최근 8주 평균, 없으면 전체 평균)

출력: features_<cut>.parquet, feature_list.json
"""
import json
import sys
from pathlib import Path

import os
import numpy as np
import pandas as pd
from sklearn.cluster import KMeans

SRC, OUT = Path(sys.argv[1]), Path(sys.argv[2])
WHICH = sys.argv[3:] or ["A", "B", "final"]
OUT.mkdir(parents=True, exist_ok=True)
CUTS = {"A": ("2025-06-30", "2025-10-31"), "B": ("2026-02-28", "2026-06-30"), "final": ("2026-06-30", "2026-10-31")}
LAG_SHORT, LAG_YEAR = 123, 364
# 관문 환승역: 행사장 노선으로 갈아타는 역 (팀 환승역 피처 정의, 스타디움 공연·규모 3 축제만)
GATEWAYS = {1: [3110, 3120, 3118, 3761, 3124, 3221, 3130], 2: [3207, 3218, 3213, 3763, 3221, 3124], 7: [3761, 3118, 3763, 3213]}

ALL = pd.read_parquet(SRC)
ALL["y"] = np.log1p(ALL.boardings)
ALL["y_rob"] = np.log1p(ALL.boardings_robust)
# 요일 유형: 0 평일, 1 토요일, 2 일요일·공휴일
ALL["daytype"] = np.select([ALL.is_holiday == 1, ALL.dow == 6, ALL.dow == 5], [2, 2, 1], 0).astype("int8")
ALL["month"] = ALL.date.dt.month.astype("int8")
ALL["dom"] = ALL.date.dt.day.astype("int8")
ALL["doy"] = ALL.date.dt.dayofyear.astype("int16")
ALL["t_days"] = (ALL.date - pd.Timestamp("2025-01-01")).dt.days.astype("int16")
ALL["l1_ext_open"] = ((ALL.line == 1) & (ALL.date >= "2025-06-28")).astype("int8")
ALL["days_since_open_c"] = ALL.days_since_open.clip(upper=400)
ALL["hour_block"] = pd.cut(ALL.hour, [5, 9, 16, 19, 23], labels=False).astype("int8")  # 출근·낮·퇴근·밤

# ---------------------------------------------------------------- 계절 피처 (노이즈역 전용, 외부 근거로 날짜 고정)
# 인천대공원(3226) 벚꽃: 2025 절정 4/14(학습 데이터), 2026 절정 = 2025 - 6일 = 4/8
#   (기상청 서울 벚꽃 개화 2025-04-04 → 2026-03-29, 6일 빠름. 2026 학습 데이터로 정하지 않아 검증 B 누출 없음)
# 인천대공원 단풍: 절정 = 기상청 북한산 첫 단풍 + 18일 (2025 10/22→11/09, 2026 10/14→11/01)
# 인천대공원 물놀이장: 2025 8/1~8/31·9/2~9/7, 2026 7/14~8/23, 월요일 휴장 (인천시 공지)
# 부천종합운동장(3754) 진달래철: 부천페스타 봄꽃여행 시작일 ~ 종료일+6일 (2025 3/29~4/12, 2026 3/28~4/11)
def tri(dates, peak, before, after):
    dd = (dates - pd.Timestamp(peak)).dt.days
    return np.where(dd < 0, np.clip(1 + dd / before, 0, 1), np.clip(1 - dd / after, 0, 1))


is_park = ALL.station_id.astype(int) == 3226
ALL["park_cherry_w"] = np.where(is_park, np.maximum(tri(ALL.date, "2025-04-14", 9, 12), tri(ALL.date, "2026-04-08", 9, 12)), 0.0)
ALL["park_foliage_w"] = np.where(is_park, np.maximum(tri(ALL.date, "2025-11-09", 16, 9), tri(ALL.date, "2026-11-01", 16, 9)), 0.0)
wp = ((ALL.date.between("2025-08-01", "2025-08-31") | ALL.date.between("2025-09-02", "2025-09-07")
       | ALL.date.between("2026-07-14", "2026-08-23")) & (ALL.dow != 0))
ALL["park_waterpark"] = (is_park & wp).astype("int8")
ALL["bc_azalea"] = ((ALL.station_id.astype(int) == 3754) & (ALL.date.between("2025-03-29", "2025-04-12")
                                                           | ALL.date.between("2026-03-28", "2026-04-11"))).astype("int8")
if os.environ.get("DATA_V2") and not os.environ.get("KEEP_AZALEA"):  # 통합 자료(2026-11-12)에 원미산 진달래축제가 없음 → 끔
    ALL["bc_azalea"] = np.int8(0)
ALL["season_w"] = np.maximum.reduce([ALL.park_cherry_w, ALL.park_foliage_w, ALL.bc_azalea.astype(float)])

# ---------------------------------------------------------------- 날씨 세부 피처 (Open-Meteo 시간별 원자료, 외부 자료만 사용)
import os
WX = os.environ.get("WEATHER_RAW", "ext_in/external/weather_hourly.csv")
EVF = os.environ.get("EVENTS_CSV", "ext_clean/events.csv")
wr = pd.read_csv(WX, encoding="utf-8-sig", parse_dates=["date"]).sort_values(["date", "hour"]).reset_index(drop=True)
wr["precip_next1h"] = wr.precip_mm.shift(-1).fillna(0)
wr["precip_next2h"] = wr.precip_mm.shift(-1).fillna(0) + wr.precip_mm.shift(-2).fillna(0)
wr["heavy_rain_h"] = (wr.precip_mm >= 5).astype("int8")
wr["temp_anom"] = wr.temp_c - wr.groupby("hour").temp_c.transform(lambda x: x.rolling(30 * 1, min_periods=7, center=True).mean())
wd_ = wr.groupby("date").agg(
    precip_am=("precip_mm", lambda x: x.iloc[7:10].sum()), precip_mid=("precip_mm", lambda x: x.iloc[10:17].sum()),
    precip_pm=("precip_mm", lambda x: x.iloc[17:21].sum()), precip_prev_eve=("precip_mm", lambda x: x.iloc[18:24].sum()),
    tmax_=("temp_c", "max"), tmin_=("temp_c", "min"), pday_=("precip_mm", "sum")).reset_index()
wd_["precip_prev_eve"] = wd_.precip_prev_eve.shift(1).fillna(0)
wd_["heavy_rain_day"] = (wd_.pday_ >= 30).astype("int8")
wd_["heat_day"] = (wd_.tmax_ >= 33).astype("int8")
wd_["cold_day"] = (wd_.tmin_ <= -10).astype("int8")
rainy = (wd_.pday_ >= 1).astype(int)
wd_["rain_streak"] = rainy.groupby((rainy != rainy.shift()).cumsum()).cumsum() * rainy
ALL = ALL.merge(wr[["date", "hour", "precip_next1h", "precip_next2h", "heavy_rain_h", "temp_anom"]], on=["date", "hour"], how="left")
ALL = ALL.merge(wd_[["date", "precip_am", "precip_mid", "precip_pm", "precip_prev_eve", "heavy_rain_day", "heat_day", "cold_day",
                     "rain_streak"]], on="date", how="left")
ALL["rain_offday_mid"] = ALL.precip_mid * ALL.is_offday

# ---------------------------------------------------------------- 행사 세부 피처 (행사장 역)
evs = pd.read_csv(EVF, encoding="utf-8-sig", parse_dates=["date"])
evs = evs[(evs.use_default == 1) & (evs.played == 1)].copy()
offd = set(ALL.loc[ALL.is_offday == 1, "date"])
dflt_s = {"kbo": 18.5, "kleague": 19.0, "fest": 11.0, "season": 10.0, "kbo_cancel": 18.5}
evs["s0"] = [r.start_hour if not pd.isna(r.start_hour) else (18.0 if r.date in offd else 19.0) if r.kind == "concert" else dflt_s[r.kind]
             for r in evs.itertuples()]
dur = {"kbo": 3.25, "kleague": 2.0, "concert": 3.5, "kbo_cancel": 1.0}
evs["e0"] = [r.end_hour if not pd.isna(r.end_hour) else (r.s0 + dur[r.kind] if r.kind in dur else 21.0 if r.kind == "fest" else 18.0)
             for r in evs.itertuples()]
# 여러 날 행사: 같은 역·같은 code가 연속된 날짜를 한 묶음으로
evs = evs.sort_values(["station_id", "code", "date"])
grp_id = ((evs.date.diff().dt.days != 1) | (evs.station_id != evs.station_id.shift()) | (evs.code != evs.code.shift())).cumsum()
evs["evt_day_idx"] = evs.groupby(grp_id).cumcount() + 1
evs["evt_n_days"] = evs.groupby(grp_id).date.transform("size")
evs["evt_last_day"] = (evs.evt_day_idx == evs.evt_n_days).astype(int)
ed = evs.groupby(["date", "station_id"]).agg(ev_s=("s0", "min"), ev_e=("e0", "max"), evt_day_idx=("evt_day_idx", "max"),
                                             evt_n_days=("evt_n_days", "max"), evt_last_day=("evt_last_day", "max"),
                                             evt_att_any_k=("attendance", "max"), evt_count=("kind", "size")).reset_index()
ed["evt_att_any_k"] /= 1000
ed["station_id"] = ed.station_id.astype(ALL.station_id.dtype)
ALL = ALL.merge(ed, on=["date", "station_id"], how="left")
ALL["evt_h_from_start"] = ALL.hour.astype(float) - ALL.ev_s
ALL["evt_h_from_end"] = ALL.hour.astype(float) - ALL.ev_e
ALL["evt_count"] = ALL.evt_count.fillna(0).astype("int8")
ALL["rain_evt"] = ALL.precip_mm * ((ALL.evt_on == 1) | (ALL.evt_exit == 1))
ALL["rain_season"] = ALL.precip_mid * ALL.season_w
ALL = ALL.drop(columns=["ev_s", "ev_e"])

# ---------------------------------------------------------------- 날짜와 무관한 행사 전파 (외부 자료만 사용)
st = ALL.drop_duplicates("station_id").set_index("station_id")[["line", "prev_station", "next_station", "transfer_pair"]]
nbrs = {s: [x for x in (r.prev_station, r.next_station, r.transfer_pair) if x] for s, r in st.iterrows()}
ev_h = ALL.loc[(ALL.evt_on == 1) | (ALL.evt_exit == 1), ["date", "station_id", "hour", "evt_on", "evt_exit", "evt_concert", "evt_fest", "evt_scale_max"]]
rows = []
for r in ev_h.itertuples():
    for nb in nbrs[r.station_id]:
        rows.append((r.date, nb, r.hour, r.evt_on, r.evt_exit, 0, 0))
    if r.evt_concert or (r.evt_fest and r.evt_scale_max >= 3):
        for g in GATEWAYS[st.line[r.station_id]]:
            if g != r.station_id:
                rows.append((r.date, g, r.hour, 0, 0, r.evt_on, r.evt_exit))
prop = pd.DataFrame(rows, columns=["date", "station_id", "hour", "nb_evt_on", "nb_evt_exit", "gw_evt_on", "gw_evt_exit"])
prop = prop.groupby(["date", "station_id", "hour"]).max().reset_index()
ALL = ALL.merge(prop, on=["date", "station_id", "hour"], how="left")
for c in ["nb_evt_on", "nb_evt_exit", "gw_evt_on", "gw_evt_exit"]:
    ALL[c] = ALL[c].fillna(0).astype("int8")

KEY = ["station_id", "hour", "daytype"]


def normal_mask(d):
    """역 수준을 잴 때 쓰는 '평소 날' (행사·공휴일·징검다리·오류·개통 첫 주 제외)"""
    return ((d.evt_any == 0) & (d.nb_evt_exit == 0) & (d.season_w < 0.3) & (d.is_holiday == 0) & (d.is_bridge_day == 0)
            & (d.is_quasi_holiday == 0) & (d.flag_suspect_error == 0) & (d.is_open_week == 0))


def lodo_mean(hist, rows, keys, val):
    """keys별 평균을 rows에 붙이되, 같은 날짜가 hist에 있으면 그 날짜를 빼고 계산 (leave-one-date-out)"""
    g = hist.groupby(keys)[val].agg(["sum", "count"]).reset_index()
    gd = hist.groupby(keys + ["date"])[val].agg(["sum", "count"]).reset_index().rename(columns={"sum": "sd", "count": "cd"})
    out = rows[keys + ["date"]].merge(g, on=keys, how="left").merge(gd, on=keys + ["date"], how="left")
    s = out["sum"] - out.sd.fillna(0)
    c = out["count"] - out.cd.fillna(0)
    return (s / c.where(c > 0)).to_numpy()


def build(cut_name):
    cutoff, end = map(pd.Timestamp, CUTS[cut_name])
    d = ALL[ALL.date <= end].copy().reset_index(drop=True)
    d["is_target"] = (d.date > cutoff).astype("int8")
    hist = d[(d.date <= cutoff) & (d.is_test == 0)].copy()
    hist["normal"] = normal_mask(hist)
    hn = hist[hist.normal]

    # ---------------- 역·시간·요일유형 수준 (1·2위 그룹 통계의 기준일 버전)
    last8 = hn[hn.date > cutoff - pd.Timedelta(days=56)]
    prev8 = hn[(hn.date <= cutoff - pd.Timedelta(days=56)) & (hn.date > cutoff - pd.Timedelta(days=112))]
    lv = hn.groupby(KEY).y_rob.agg(lvl_all="mean", lvl_std="std", lvl_n="count").reset_index()
    lv = lv.merge(last8.groupby(KEY).y_rob.mean().rename("lvl_8w").reset_index(), on=KEY, how="left")
    lv = lv.merge(prev8.groupby(KEY).y_rob.mean().rename("lvl_prev8w").reset_index(), on=KEY, how="left")
    lv["trend_8w"] = lv.lvl_8w - lv.lvl_prev8w
    d = d.merge(lv.drop(columns="lvl_prev8w"), on=KEY, how="left")
    # 역 단위 수준·추세, 노선 단위 시간대 수준 (신규역 대체값)
    s8 = last8.groupby(["station_id", "daytype"]).y_rob.mean().rename("st_lvl_8w").reset_index()
    sp = prev8.groupby(["station_id", "daytype"]).y_rob.mean().rename("st_lvl_prev8w").reset_index()
    s8 = s8.merge(sp, on=["station_id", "daytype"], how="left")
    s8["st_trend_8w"] = s8.st_lvl_8w - s8.st_lvl_prev8w
    d = d.merge(s8.drop(columns="st_lvl_prev8w"), on=["station_id", "daytype"], how="left")
    lh = last8.groupby(["line", "hour", "daytype"]).y_rob.mean().rename("line_lvl_8w").reset_index()
    d = d.merge(lh, on=["line", "hour", "daytype"], how="left")
    # 노선 안 순위 (최근 8주 평일 일평균)
    wk = last8[last8.daytype == 0].groupby(["station_id", "line", "date"]).boardings.sum().groupby(["station_id", "line"]).mean().reset_index()
    wk["st_rank_line_pct"] = wk.groupby("line").boardings.rank(ascending=False, pct=True)
    d = d.merge(wk[["station_id", "st_rank_line_pct"]], on="station_id", how="left")
    # 휴일/평일 비율 (역 특성)
    od = lv.pivot_table(index=["station_id", "hour"], columns="daytype", values="lvl_all")
    od = (od[2] - od[0]).groupby("station_id").mean().rename("st_offday_vs_weekday")
    d["st_offday_vs_weekday"] = d.station_id.map(od)

    # base: 최근 8주 → 전체 → 노선 평균 + 역 차이 순으로 대체
    d["base"] = d.lvl_8w.fillna(d.lvl_all).fillna(d.line_lvl_8w)
    d["base_src"] = np.select([d.lvl_8w.notna(), d.lvl_all.notna()], [0, 1], 2).astype("int8")

    # ---------------- 지연 수준 (학습·예측 행에서 같은 뜻을 갖도록 날짜 기준 이동)
    hn_y = hn[["date", "station_id", "hour", "daytype", "y_rob"]]
    for lag, win, name in [(LAG_SHORT, 56, "lag123_lvl"), (LAG_YEAR, 28, "ly_lvl")]:
        parts = []
        for dt in (0, 1, 2):
            pv = hn_y[hn_y.daytype == dt].pivot_table(index="date", columns=["station_id", "hour"], values="y_rob")
            pv = pv.reindex(pd.date_range(d.date.min() - pd.Timedelta(days=lag), cutoff))
            rl = pv.rolling(f"{win}D", min_periods=3).mean()
            rl.index = rl.index + pd.Timedelta(days=lag)  # 이동: d일 값 = (d-lag)일까지의 평균
            m = rl.stack(["station_id", "hour"], future_stack=True).rename(name).reset_index().rename(columns={"level_0": "date"})
            m["daytype"] = dt
            parts.append(m.dropna())
        lagdf = pd.concat(parts)
        d = d.merge(lagdf, on=["date", "station_id", "hour", "daytype"], how="left")
        d[f"{name}_diff"] = d.base - d[name]  # 지연값 이후 변화량

    # ---------------- 공휴일·명절·징검다리 반응 (역·시간대별, 자기 날짜 제외)
    hist = hist.merge(lv[KEY + ["lvl_all"]], on=KEY, how="left")
    base_dt = lv.pivot_table(index=["station_id", "hour"], columns="daytype", values="lvl_all")
    hist["dev2"] = hist.y_rob - hist.set_index(["station_id", "hour"]).index.map(base_dt[2]).to_numpy()
    hist["dev0"] = hist.y_rob - hist.set_index(["station_id", "hour"]).index.map(base_dt[0]).to_numpy()
    wkday_hol = hist[(hist.is_holiday == 1) & (hist.dow < 5) & (hist.is_seollal == 0) & (hist.is_chuseok == 0)]
    major = hist[(hist.is_seollal == 1) | (hist.is_chuseok == 1)]
    bridge = hist[(hist.is_bridge_day == 1) | (hist.is_quasi_holiday == 1)]
    d["hol_dev_sh"] = np.where(d.is_holiday.eq(1) & d.dow.lt(5) & d.is_seollal.eq(0) & d.is_chuseok.eq(0),
                               lodo_mean(wkday_hol, d, ["station_id", "hour"], "dev2"), np.nan)
    d["major_dev_sh"] = np.where(d.is_seollal.eq(1) | d.is_chuseok.eq(1), lodo_mean(major, d, ["station_id", "hour"], "dev2"), np.nan)
    d["bridge_dev_s"] = np.where(d.is_bridge_day.eq(1) | d.is_quasi_holiday.eq(1), lodo_mean(bridge, d, ["station_id"], "dev0"), np.nan)

    # ---------------- 행사 효과 (역·종류·진행/귀가별 과거 평균 편차, 자기 날짜 제외)
    hist["dev"] = hist.y_rob - hist.lvl_all
    for kind in ["kbo", "kleague", "concert", "fest"] + (["kbo_cancel"] if "evt_kbo_cancel" in d.columns else []):
        for ph in ["on", "exit"]:
            sel = (hist[f"evt_{kind}"] == 1) & (hist[f"evt_{ph}"] == 1)
            v = lodo_mean(hist[sel], d, ["station_id", "hour_block"], "dev")
            mask = (d[f"evt_{kind}"] == 1) & (d[f"evt_{ph}"] == 1)
            d[f"te_{kind}_{ph}"] = np.where(mask, v, np.nan)
    # 인접·관문역 반응
    for col in ["nb_evt_exit", "gw_evt_exit"]:
        sel = (hist[col] == 1) & (hist.evt_any == 0)
        d[f"te_{col}"] = np.where(d[col] == 1, lodo_mean(hist[sel], d, ["station_id"], "dev"), np.nan)

    # ---------------- 역 이용 패턴 군집 (3위 KMeans를 역 단위로)
    prof = hn.groupby(["station_id", "daytype", "hour"]).boardings.mean().unstack(["daytype", "hour"])
    prof = prof.reindex(columns=pd.MultiIndex.from_product([[0, 2], range(6, 24)])).fillna(0)
    prof = prof.div(prof.sum(axis=1), axis=0).fillna(0)
    km = KMeans(n_clusters=8, n_init=20, random_state=42).fit(prof.to_numpy())
    d["prof_cluster"] = d.station_id.map(dict(zip(prof.index, km.labels_))).astype("float32")
    pk = prof[0]  # 평일 모양: 출근 정점 비율 (주거지 vs 업무지)
    d["am_peak_share"] = d.station_id.map((pk[[7, 8]].sum(axis=1)) / (pk[[18, 19]].sum(axis=1) + 1e-6))

    # ---------------- 목표
    d["y_dev"] = d.y - d.base
    d["w"] = d.sample_weight.fillna(1.0)
    return d


FEATS = {
    "범주": ["station_id", "line", "hour", "daytype", "dow", "prof_cluster", "hour_block"],
    "달력": ["is_holiday", "is_offday", "is_seollal", "is_chuseok", "offday_block_len", "offday_block_pos",
           "days_to_next_offday", "days_from_prev_offday", "is_bridge_day", "is_quasi_holiday", "is_long_holiday",
           "month", "dom", "doy", "t_days", "vac_elem", "vac_middle", "vac_high", "vac_all", "univ_semester"],
    "날씨": ["precip_mm", "precip_prev3h", "is_rain", "temp_c", "precip_day", "precip_6_23", "rain_hours",
           "temp_max", "temp_min", "snow_day", "precip_prev_day"],
    "역 정보": ["order_idx", "rel_position", "cum_km_from_end_a", "is_terminal_now", "was_terminal_until_20250627",
              "is_transfer", "transfer_ext_line", "n_lines_same_name", "station_age_years", "days_since_open_c",
              "is_new_station", "l1_ext_open", "tt_trains_total", "tt_headway_min", "tt_trains_dir_a", "tt_trains_dir_b",
              "gumdan_pop_k", "movein_units_cum"],
    "행사": ["evt_any", "evt_kbo", "evt_kleague", "evt_concert", "evt_fest", "evt_scale_max", "evt_on", "evt_exit",
           "kbo_start", "kbo_end", "kbo_dur", "kbo_att_k", "kbo_exh", "kbo_n_games", "kleague_att_k", "evt_start_min", "nb_evt_on", "nb_evt_exit", "gw_evt_on", "gw_evt_exit"],
    "기준일 통계": ["base", "base_src", "lvl_all", "lvl_std", "lvl_n", "lvl_8w", "trend_8w", "st_lvl_8w", "st_trend_8w",
               "line_lvl_8w", "st_rank_line_pct", "st_offday_vs_weekday", "am_peak_share"],
    "계절(노이즈역)": ["park_cherry_w", "park_foliage_w", "park_waterpark", "bc_azalea"],
    "날씨2": ["precip_next1h", "precip_next2h", "heavy_rain_h", "temp_anom", "precip_am", "precip_mid", "precip_pm",
             "precip_prev_eve", "heavy_rain_day", "heat_day", "cold_day", "rain_streak", "rain_offday_mid"],
    "행사2": ["evt_h_from_start", "evt_h_from_end", "evt_day_idx", "evt_n_days", "evt_last_day", "evt_att_any_k", "evt_count",
             "rain_evt", "rain_season"],
    "지연": ["lag123_lvl", "lag123_lvl_diff", "ly_lvl", "ly_lvl_diff"],
    "반응(자기 날짜 제외)": ["hol_dev_sh", "major_dev_sh", "bridge_dev_s", "te_kbo_on", "te_kbo_exit", "te_kleague_on",
                     "te_kleague_exit", "te_concert_on", "te_concert_exit", "te_fest_on", "te_fest_exit",
                     "te_nb_evt_exit", "te_gw_evt_exit"],
}
if os.environ.get("DATA_V2"):  # 통합 자료: 취소 경기 추가, 입주 일정·진달래축제 제외
    FEATS["행사"].append("evt_kbo_cancel")
    FEATS["반응(자기 날짜 제외)"].append("te_kbo_cancel_exit")
    FEATS["역 정보"].remove("movein_units_cum")
    if not os.environ.get("KEEP_AZALEA"):
        FEATS["계절(노이즈역)"].remove("bc_azalea")
feat_list = [c for g in FEATS.values() for c in g]
keep = ["date", "station_id", "hour", "example_id", "is_test", "is_target", "boardings", "y", "y_dev", "w"] + feat_list
keep = list(dict.fromkeys(keep))
for name in WHICH:
    f = build(name)
    f[keep].to_parquet(OUT / f"features_{name}.parquet", index=False)
    tr, tg = f[f.is_target == 0], f[f.is_target == 1]
    na = tg[feat_list].isna().mean()
    print(f"{name}: 학습 {len(tr):,}행 / 예측 {len(tg):,}행, 피처 {len(feat_list)}개. 예측 행 빈 값 50% 넘는 열:",
          na[na > 0.5].round(2).to_dict())
json.dump({"features": feat_list, "groups": FEATS, "categorical": FEATS["범주"], "target": "y_dev", "base": "base",
           "weight": "w"}, open(OUT / "feature_list.json", "w"), ensure_ascii=False, indent=1)
