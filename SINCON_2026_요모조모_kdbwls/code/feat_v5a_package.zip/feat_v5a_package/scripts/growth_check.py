"""예측이 작년 같은 달 대비 얼마로 나왔는지(암묵 성장률) vs 기준일 직전 실제 전년비 비교, 보정 시험"""
import sys
import numpy as np, pandas as pd
cut, predf, featf = sys.argv[1], sys.argv[2], sys.argv[3]
d = pd.read_parquet(featf, columns=['date','station_id','hour','is_target','boardings','daytype','y','is_holiday','evt_any'])
p = np.load(predf)
d['sid'] = d.station_id.astype(int)
te = d[d.is_target == 1].reset_index(drop=True).assign(P=np.expm1(p))
co = te.date.min() - pd.Timedelta(days=1)
tr = d[d.is_target == 0]
norm = lambda x: x[(x.daytype == 0) & (x.is_holiday == 0) & (x.evt_any == 0)]
def dl(x, col):  # 역별 평일 하루 평균 (log)
    x = norm(x); return np.log(x.groupby(['sid', 'date'])[col].sum().groupby('sid').mean())
ly = tr[(tr.date >= te.date.min() - pd.DateOffset(years=1)) & (tr.date <= te.date.max() - pd.DateOffset(years=1))]
implied = dl(te, 'P') - dl(ly, 'boardings')
rec = tr[tr.date > co - pd.Timedelta(days=56)]; rec_ly = tr[(tr.date > co - pd.Timedelta(days=56) - pd.DateOffset(years=1)) & (tr.date <= co - pd.DateOffset(years=1))]
yoy = dl(rec, 'boardings') - dl(rec_ly, 'boardings')
t = pd.concat([implied.rename('implied'), yoy.rename('yoy')], axis=1)
t['gap'] = t.yoy - t.implied
print(cut, '중앙값 implied', round(t.implied.median(), 4), 'yoy', round(t.yoy.median(), 4), 'gap', round(t.gap.median(), 4))
if te.y.notna().all():
    y = te.y.to_numpy()
    actual = dl(te.assign(B=np.expm1(te.y)), 'B') - dl(ly, 'boardings')
    t['actual'] = actual
    print('실제 전년비 중앙값', round(t.actual.median(), 4), '실제-암묵', round((t.actual - t.implied).median(), 4))
    r = lambda q: round(float(np.sqrt(np.mean((q - y) ** 2))), 4)
    g = t.gap.clip(-0.1, 0.1)
    for name, sh in [('보정 없음', 0), ('전체 중앙값 gap', te.sid.map(lambda s: t.gap.median()).to_numpy()),
                     ('역별 gap(±0.1) 절반', 0.5 * te.sid.map(g).fillna(0).to_numpy()), ('역별 gap(±0.1)', te.sid.map(g).fillna(0).to_numpy())]:
        print(' ', name, r(p + sh))
print(t.round(3).sort_values('gap').tail(6))
