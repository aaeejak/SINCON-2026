"""SINCON 2026 - 데이콘 전략 실험 공통 함수 (1차 예측 보정 모델)

목표 두 가지
  dev : y_dev = y - base  (기존 직접 예측)
  res : y_res = y - s1    (1차 예측 보정, s1이 없는 2025년 1~2월 학습 행은 base로 채움)
"""
import json
import time
from pathlib import Path

import lightgbm as lgb
import numpy as np
import pandas as pd

NOISE = [3127, 3754, 3226, 3209, 3122, 3210, 3139]
WXL_DROP = ["temp_anom", "rain_streak", "precip_prev_eve", "precip_next2h", "heavy_rain_h", "cold_day", "precip_mid"]
LGB_PARAMS = dict(objective="regression", learning_rate=0.05, num_leaves=127, min_data_in_leaf=40, feature_fraction=0.7,
                  bagging_fraction=0.8, bagging_freq=1, lambda_l2=1.0, verbose=-1, num_threads=0)


def feature_sets(meta):
    G = meta["groups"]
    g = lambda *names: [c for n in names for c in G[n]]
    wx2l = [c for c in G["날씨2"] if c not in WXL_DROP]
    core = g("범주", "달력", "1차 예측")
    fs = {
        "R0_직접(1차 없음)": [c for c in meta["features"] if c not in G["1차 예측"] + WXL_DROP],
        "FS1_1차+달력": core,
        "FS2_1차+날씨": core + g("날씨") + wx2l,
        "FS3_1차+행사": core + g("행사", "행사2", "반응(자기 날짜 제외)", "계절(노이즈역)"),
        "FS4_1차+역·통계·지연": core + g("역 정보", "기준일 통계", "지연"),
    }
    fs["FS5_전체"] = [c for c in meta["features"] if c not in WXL_DROP]
    return fs


def feature_sets_for(meta, target):
    """target=dev 이면 1차 예측 피처를 뺀 같은 묶음 (FS5 = R0)"""
    fs = feature_sets(meta)
    if target == "res":
        return fs
    s1 = meta["groups"]["1차 예측"]
    return {k: [c for c in v if c not in s1] for k, v in fs.items()}


def lgb_fs5_file(D, target):
    return D / ("lgb_FS5.npy" if target == "res" else "lgb_R0.npy")


def load(F, cut):
    meta = json.load(open(F / "feature_list.json"))
    d = pd.read_parquet(F / f"features_{cut}.parquet")
    for c in meta["categorical"]:
        d[c] = d[c].astype("category")
    d["is_noise"] = d.station_id.astype(int).isin(NOISE).to_numpy()
    d["s1f"] = d.s1_log.fillna(d.base)
    # 2025-06-28 검단 연장 개통 역·옛 종점은 기준일 2025-06-30 1차 예측에 개통 후 이력이 없음 → base로 대체
    bad = d.date.between("2025-07-01", "2025-10-31") & ((d.is_new_station == 1) | (d.was_terminal_until_20250627 == 1))
    d.loc[bad, "s1f"] = d.loc[bad, "base"]
    d["y_res"] = d.y - d.s1f
    return d, meta


def offset(d, target):
    return (d.base if target == "dev" else d.s1f).to_numpy()


def ycol(target):
    return "y_dev" if target == "dev" else "y_res"


def fit_lgb(tr, te, feats, cats, target="res", params=None, seeds=(42,), rounds=700, weight=None, ret_model=False):
    tr = tr[tr[ycol(target)].notna()]
    w = tr.w.to_numpy() if weight is None else weight[tr.index] if isinstance(weight, pd.Series) else weight
    ds = lgb.Dataset(tr[feats], tr[ycol(target)], weight=w, categorical_feature=[c for c in cats if c in feats], free_raw_data=False)
    p = np.zeros(len(te))
    models = []
    for s in seeds:
        m = lgb.train({**LGB_PARAMS, **(params or {}), "seed": s}, ds, rounds)
        p += m.predict(te[feats]) / len(seeds)
        models.append(m)
    out = np.clip(offset(te, target) + p, 0, None)
    return (out, models) if ret_model else out


def rmsle(p, y):
    return float(np.sqrt(np.mean((np.asarray(p) - np.asarray(y)) ** 2)))


def score(te, p):
    y, nz = te.y.to_numpy(), te.is_noise.to_numpy()
    p = np.asarray(p)
    return dict(all=round(rmsle(p, y), 4), normal=round(rmsle(p[~nz], y[~nz]), 4), noise=round(rmsle(p[nz], y[nz]), 4))


def halves(te):
    """예측 구간을 날짜 앞/뒤 절반으로 나눔 (가중치 고르기용 별도 검증)"""
    dates = np.sort(te.date.unique())
    mid = dates[len(dates) // 2]
    h1 = (te.date < mid).to_numpy()
    return h1, ~h1


class Log:
    def __init__(self, path):
        self.path = Path(path)
        self.t0 = time.time()
        self.rows = json.load(open(self.path)) if self.path.exists() else []

    def add(self, **kw):
        kw["sec"] = round(time.time() - self.t0)
        self.t0 = time.time()
        self.rows.append(kw)
        json.dump(self.rows, open(self.path, "w"), ensure_ascii=False, indent=1)
        print(kw, flush=True)
