"""정리된 외부 자료를 대회 데이터(combined.parquet)에 붙여 모델 입력 기본표를 만든다.

사용법: python join_external.py <combined.parquet> <ext_clean 폴더> <출력 parquet>
- 행사는 use_default=1 인 행만 쓴다 (출처·날짜 확인된 것)
- 인접역·관문 환승역으로 퍼뜨리는 피처는 피처 단계에서 station_static.csv의 prev/next/transfer_pair로 만든다
"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd

comb, EXT, OUT = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
df = pd.read_parquet(comb)
n0 = len(df)


def rd(name, **kw):
    return pd.read_csv(EXT / f"{name}.csv", encoding="utf-8-sig", **kw)


cal = rd("calendar_daily", parse_dates=["date"]).drop(columns=["dow", "holiday_kind"])
df = df.merge(cal, on="date", how="left")
df = df.merge(rd("weather_hourly", parse_dates=["date"]), on=["date", "hour"], how="left")
st = rd("station_static").drop(columns=["station_name", "line"])
st["open_date"] = pd.to_datetime(st.open_date)
df = df.merge(st, on="station_id", how="left")
df["station_age_years"] = ((df.date - df.open_date).dt.days / 365.25).round(2)
df = df.drop(columns="open_date")
df["seg_km_from_prev"] = df.seg_km_from_prev.fillna(0)  # 노선 첫 역
df = df.merge(rd("ops_hourly", parse_dates=["date"]), on=["date", "station_id", "hour"], how="left")
gd = rd("geomdan_station_daily", parse_dates=["date"])
df = df.merge(gd, on=["date", "station_id"], how="left")
df[["movein_units_cum", "movein_units_cum_confirmed"]] = df[["movein_units_cum", "movein_units_cum_confirmed"]].fillna(0)

# 행사: 역·날짜 단위
ev = rd("events", parse_dates=["date"])
ev = ev[ev.use_default == 1]
day = ev.groupby(["date", "station_id"]).agg(
    evt_any=("kind", "size"), evt_scale_max=("scale", "max"), evt_start_min=("start_hour", "min")).reset_index()
day["evt_any"] = 1
for k in ["kbo", "kleague", "concert", "fest", "season", "kbo_cancel"]:
    sub = ev[ev.kind == k].groupby(["date", "station_id"]).size().rename(f"evt_{k}").reset_index()
    sub[f"evt_{k}"] = 1
    day = day.merge(sub, on=["date", "station_id"], how="left")
kl = ev[ev.kind == "kleague"].groupby(["date", "station_id"]).attendance.max().rename("kleague_att_k").reset_index()
kl["kleague_att_k"] /= 1000
day = day.merge(kl, on=["date", "station_id"], how="left")
kbo = ev[ev.kind == "kbo"].groupby(["date", "station_id"]).agg(
    kbo_start=("start_hour", "min"), kbo_end=("end_hour", "max"), kbo_n_games=("n_games", "max"),
    kbo_att_k=("attendance", "max"), kbo_exh=("is_exhibition", "max")).reset_index()
kbo["kbo_att_k"] /= 1000
kbo["kbo_dur"] = kbo.kbo_end - kbo.kbo_start
day = day.merge(kbo, on=["date", "station_id"], how="left")
df = df.merge(day, on=["date", "station_id"], how="left")
flag_cols = ["evt_any", "evt_scale_max", "evt_kbo", "evt_kleague", "evt_concert", "evt_fest", "evt_season", "evt_kbo_cancel", "kbo_n_games", "kbo_exh"]
df[flag_cols] = df[flag_cols].fillna(0).astype("int8")

# 행사: 시간 단위 (진행·귀가)
eh = rd("events_hourly", parse_dates=["date"])
eh = eh[eh.use_default == 1].groupby(["date", "station_id", "hour"])[["evt_on", "evt_exit"]].max().reset_index()
df = df.merge(eh, on=["date", "station_id", "hour"], how="left")
df[["evt_on", "evt_exit"]] = df[["evt_on", "evt_exit"]].fillna(0).astype("int8")

assert len(df) == n0, "조인 후 행 수가 달라짐"
df.to_parquet(OUT, index=False)

# 점검: 값이 비어 있으면 안 되는 열
must = [c for c in df.columns if c not in {"boardings", "alightings", "example_id", "holiday_name", "evt_start_min",
                                            "kleague_att_k", "kbo_start", "kbo_end", "kbo_att_k", "kbo_dur", "tt_headway_min", "boardings_robust", "sample_weight"}]
na = df[must].isna().sum()
print("빈 값 있는 열:", na[na > 0].to_dict())
print(df.shape)
for part, g in df.groupby("is_test"):
    print("test" if part else "train", len(g), "행사 시간 비율", round(g.evt_on.mean() + g.evt_exit.mean(), 4),
          "공휴일 날", g.loc[g.is_holiday == 1, "date"].nunique(), "강수일", g.loc[g.precip_6_23 >= 1, "date"].nunique())
