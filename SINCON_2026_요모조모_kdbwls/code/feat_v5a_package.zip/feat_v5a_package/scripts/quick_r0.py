"""직접 모델 R0 (시드 1, 전체 학습) 빠른 비교: python quick_r0.py <피처 폴더> <A|B> [출력 npy]"""
import sys
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path(__file__).parent))
from dlib import feature_sets_for, fit_lgb, load, score  # noqa: E402
F, CUT = Path(sys.argv[1]), sys.argv[2]
d, meta = load(F, CUT)
feats = feature_sets_for(meta, "dev")["FS5_전체"]
tr, te = d[(d.is_target == 0) & d.y_dev.notna()], d[d.is_target == 1].reset_index(drop=True)
p = fit_lgb(tr, te, feats, meta["categorical"], "dev", seeds=tuple(range(42, 42 + int(__import__("os").environ.get("NSEED", "1")))))
if len(sys.argv) > 3:
    np.save(sys.argv[3], p)
s = score(te, p)
m = (te.station_id.astype(int) == 3127).to_numpy()
print(F.name, CUT, len(feats), s, "문학", round(float(np.sqrt(np.mean((p[m] - te.y.to_numpy()[m]) ** 2))), 4), flush=True)
