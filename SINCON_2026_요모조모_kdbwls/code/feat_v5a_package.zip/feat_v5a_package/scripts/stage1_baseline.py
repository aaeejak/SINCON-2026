"""SINCON 2026 - 1차 예측: 과거 3개년 자료로 역별 하루 승차 x 시간대 비중 (기준일별, 누출 없음)

사용법: python stage1_baseline.py <combined_ext.parquet> <past_monthly_boardings.csv> <피처 폴더(입력)> <피처 폴더(출력)>

기준일 c, 예측 구간 (c, end]에 대해
  하루 승차  log D(s,d) = L(s, 요일유형) + seas(s, 월)
    L    : c 직전 8주 평소 날 log 하루 승차 평균 (평일 / 토 / 일·공휴일), 없으면 노선 평균
    seas : 작년 같은 달 log 하루 평균 - 작년 같은 8주 log 하루 평균 (train에 작년 자료가 있을 때)
           7~10월이면 월별 모양을 3개년(2023·2024 월보 + 기준일 이전 train 연도) 평균으로 교체
  시간대 비중 = c 직전 16주 평소 날 비중과 작년 같은 기간 비중의 평균
  1차 예측 = log1p(D x 비중)
학습 행: 4개월 블록마다 직전 날을 가상 기준일로 같은 계산 (실제 기준일 이전 블록만)
         2025년 1~2월은 직전 이력이 없어 1차 예측 없음 → s1_ok=0
"""
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

COMB, MB, FIN, FOUT = map(Path, sys.argv[1:5])
FOUT.mkdir(parents=True, exist_ok=True)
CUTS = {"A": ("2025-06-30", "2025-10-31"), "B": ("2026-02-28", "2026-06-30"), "final": ("2026-06-30", "2026-10-31")}
PSEUDO = [("2025-02-28", "2025-06-30"), ("2025-06-30", "2025-10-31"), ("2025-10-31", "2026-02-28"), ("2026-02-28", "2026-06-30")]

c = pd.read_parquet(COMB)
c["daytype"] = np.select([c.is_holiday == 1, c.dow == 6, c.dow == 5], [2, 2, 1], 0)
c["normal"] = ((c.evt_any == 0) & (c.is_holiday == 0) & (c.is_bridge_day == 0) & (c.is_quasi_holiday == 0)
               & (c.flag_suspect_error == 0) & (c.is_open_week == 0))
day = c.groupby(["station_id", "date"]).agg(D=("boardings", lambda x: x.sum(min_count=18)), daytype=("daytype", "first"),
                                            normal=("normal", "first"), line=("line", "first")).reset_index()
day["month"] = day.date.dt.month
day["year"] = day.date.dt.year
LINE = day[["station_id", "line"]].drop_duplicates()
mb = pd.read_csv(MB, encoding="utf-8-sig")
mbd = mb.groupby(["year", "month", "station_id"]).agg(tot=("boardings_month", "sum"), days=("days", "first")).reset_index()
mbd["daily"] = mbd.tot / mbd.days
hh_all = c[(c.is_test == 0) & c.normal][["station_id", "date", "hour", "daytype", "boardings"]].merge(
    day[["station_id", "date", "D"]], on=["station_id", "date"])
hh_all["sh"] = hh_all.boardings / hh_all.D
hh_all["month"] = hh_all.date.dt.month


def stage1(cutoff, end):
    cutoff, end = pd.Timestamp(cutoff), pd.Timestamp(end)
    hist = day[(day.date <= cutoff) & day.D.notna()]
    tgt = day[(day.date > cutoff) & (day.date <= end)][["station_id", "date", "daytype", "month", "line"]].copy()
    rec = hist[hist.normal & (hist.date > cutoff - pd.Timedelta(days=56))]
    L = np.log(rec.D).groupby([rec.station_id, rec.daytype]).mean().rename("L").reset_index()
    lineL = np.log(rec.D).groupby([rec.line, rec.daytype]).mean().rename("Lline").reset_index()
    tgt = tgt.merge(L, on=["station_id", "daytype"], how="left").merge(lineL, on=["line", "daytype"], how="left")
    tgt["L"] = tgt.L.fillna(tgt.Lline)
    r0, r1 = cutoff - pd.Timedelta(days=56) - pd.DateOffset(years=1), cutoff - pd.DateOffset(years=1)
    lyref = hist[(hist.date > r0) & (hist.date <= r1)].groupby("station_id").D.mean()
    w0, w1 = cutoff + pd.Timedelta(days=1) - pd.DateOffset(years=1), end - pd.DateOffset(years=1)
    lyw = hist[(hist.date >= w0) & (hist.date <= w1)]
    months = sorted(tgt.month.unique())
    seas = pd.DataFrame([(s, m) for s in day.station_id.unique() for m in months], columns=["station_id", "month"])
    if len(lyref) and len(lyw):
        md = lyw.groupby(["station_id", "month"]).D.mean()
        delta = np.log(md.div(lyref, level="station_id")).rename("delta").reset_index()
        seas = seas.merge(delta, on=["station_id", "month"], how="left")
    else:
        seas["delta"] = np.nan
    jo = [m for m in months if m in (7, 8, 9, 10)]
    if jo:
        shapes = []
        for y in [2023, 2024, 2025]:
            if y == 2025:
                h = hist[(hist.year == 2025) & hist.month.isin([7, 8, 9, 10])]
                if h.month.nunique() < 4:
                    continue
                md = h.groupby(["station_id", "month"]).D.mean().rename("daily").reset_index()
            else:
                md = mbd[(mbd.year == y) & mbd.month.isin([7, 8, 9, 10])][["station_id", "month", "daily"]]
            md = md[md.month.isin(jo)].copy()
            md["shape"] = np.log(md.daily) - np.log(md.groupby("station_id").daily.transform("mean"))
            shapes.append(md[["station_id", "month", "shape"]])
        sh = pd.concat(shapes).groupby(["station_id", "month"])["shape"].mean().rename("shape").reset_index()
        seas = seas.merge(sh, on=["station_id", "month"], how="left")
        isj = seas.month.isin(jo)
        lvl = seas[isj].groupby("station_id").delta.transform("mean")
        seas.loc[isj, "delta"] = lvl.fillna(0).to_numpy() + seas.loc[isj, "shape"].to_numpy()
    seas = seas.merge(LINE, on="station_id")
    seas["seas"] = seas.delta.fillna(seas.groupby(["line", "month"]).delta.transform("mean")).fillna(0)
    tgt = tgt.merge(seas[["station_id", "month", "seas"]], on=["station_id", "month"], how="left")
    tgt["s1_day_log"] = tgt.L + tgt.seas
    hh = hh_all[hh_all.date <= cutoff]
    rs = hh[hh.date > cutoff - pd.Timedelta(days=112)].groupby(["station_id", "daytype", "hour"]).sh.mean().rename("sh_rec")
    lys = hh[(hh.date >= w0) & (hh.date <= w1)].groupby(["station_id", "daytype", "hour", "month"]).sh.mean().rename("sh_ly")
    tc = c[(c.date > cutoff) & (c.date <= end)][["station_id", "date", "hour", "daytype"]].copy()
    tc["month"] = tc.date.dt.month
    tc = tc.join(rs, on=["station_id", "daytype", "hour"]).join(lys, on=["station_id", "daytype", "hour", "month"])
    tc["s1_share"] = tc[["sh_rec", "sh_ly"]].mean(axis=1)
    tc = tc.merge(LINE, on="station_id")
    tc["s1_share"] = tc.s1_share.fillna(tc.groupby(["line", "daytype", "hour"]).s1_share.transform("mean"))
    tc["s1_share"] = tc.s1_share / tc.groupby(["station_id", "date"]).s1_share.transform("sum")
    tc = tc.merge(tgt[["station_id", "date", "s1_day_log"]], on=["station_id", "date"])
    tc["s1_log"] = np.log1p(np.exp(tc.s1_day_log) * tc.s1_share)
    tc["s1_days_ahead"] = (tc.date - cutoff).dt.days
    return tc[["station_id", "date", "hour", "s1_log", "s1_day_log", "s1_share", "s1_days_ahead"]]


res = {}
for cut, (co, en) in CUTS.items():
    parts = [stage1(a, b) for a, b in PSEUDO if pd.Timestamp(b) <= pd.Timestamp(co)]
    parts.append(stage1(co, en))
    s1 = pd.concat(parts)
    f = pd.read_parquet(FIN / f"features_{cut}.parquet")
    key = f[["date"]].assign(station_id_i=f.station_id.astype(int).to_numpy(), hour_i=f.hour.astype(int).to_numpy())
    s1 = s1.rename(columns={"station_id": "station_id_i", "hour": "hour_i"})
    s1["station_id_i"] = s1.station_id_i.astype(int)
    s1["hour_i"] = s1.hour_i.astype(int)
    m = key.merge(s1, on=["date", "station_id_i", "hour_i"], how="left")
    for col in ["s1_log", "s1_day_log", "s1_share", "s1_days_ahead"]:
        f[col] = m[col].to_numpy()
    f["s1_ok"] = f.s1_log.notna().astype("int8")
    f["y_res"] = f.y - f.s1_log
    f["s1_vs_base"] = f.s1_log - f.base
    assert f.loc[f.is_target == 1, "s1_log"].notna().all()
    f.to_parquet(FOUT / f"features_{cut}.parquet", index=False)
    if cut != "final":
        t = f[f.is_target == 1]
        rm = lambda p: round(float(np.sqrt(np.mean((p - t.y) ** 2))), 4)
        res[cut] = dict(stage1=rm(t.s1_log), base_8w=rm(t.base), train_rows_with_s1=int(f[(f.is_target == 0)].s1_ok.sum()))
        print(cut, res[cut], flush=True)
meta = json.load(open(FIN / "feature_list.json"))
meta["groups"]["1차 예측"] = ["s1_log", "s1_day_log", "s1_share", "s1_days_ahead", "s1_vs_base"]
meta["features"] = [x for g in meta["groups"].values() for x in g]
json.dump(meta, open(FOUT / "feature_list.json", "w"), ensure_ascii=False, indent=1)
json.dump(res, open(FOUT / "stage1_results.json", "w"), ensure_ascii=False, indent=1)
