"""SINCON 2026 - 팀 조사 자료 정리 (새 모델용)

사용법: python build_external.py <입력 폴더> <대회 원본 폴더> <출력 폴더>
  입력 폴더 구조: external/, SINCON_데이터_CSV/, opszip/out/, 그리고
                  events_all_2023_2026.csv, transfer_events.csv, geomdan_move_ins.csv, rank_holidays_sources.csv

출력 (모두 2025-01-01 ~ 2026-10-31, 예측 기간 승하차 수는 쓰지 않음)
  calendar_daily.csv      date              공휴일·연휴·징검다리·방학·날씨(일)·검단 인구
  weather_hourly.csv      date, hour        시간별 강수·기온·적설 (6~23시)
  events.csv              행사 1일 1행      경기·공연·축제 통합 목록 (출처 등급, 날짜 확정 여부, 학습 기간 효과)
  events_hourly.csv       date, station_id, hour   행사 진행·귀가 시간대 (행사장 역만)
  station_static.csv      station_id        노선 순서·인접역·환승·거리·종점·개통일
  ops_hourly.csv          date, station_id, hour   공식 시각표 열차 수·배차 (1호선 개통 전 보정)
  geomdan_station_daily.csv date, station_id  검단 입주 누적 세대 (역별)
  past_monthly_boardings.csv year, month, station_id, hour  인천교통공사 월보 2023·2024 (7~10월)
  data_issues.csv         점검에서 나온 문제와 처리
"""
import re
import sys
from pathlib import Path

import numpy as np
import pandas as pd

IN, RAW, OUT = map(Path, sys.argv[1:4])
OUT.mkdir(parents=True, exist_ok=True)
START, CUTOFF, END = pd.Timestamp("2025-01-01"), pd.Timestamp("2026-06-30"), pd.Timestamp("2026-10-31")
DATES = pd.date_range(START, END)
HOURS = list(range(6, 24))
meta = pd.read_csv(RAW / "metaData.csv")
STATIONS = meta.station_id.tolist()
LINE = dict(zip(meta.station_id, meta.canonical_line))
issues = []


def issue(area, problem, action):
    issues.append(dict(area=area, problem=problem, action=action))


def rd(p, **kw):
    return pd.read_csv(IN / p, encoding="utf-8-sig", **kw)


# =====================================================================
# 1. 공휴일 달력
# =====================================================================
hol = rd("rank_holidays_sources.csv", parse_dates=["date"])[["date", "holiday_name", "kind", "source"]]
KASI26 = "한국천문연구원 2026년 달력자료 https://astro.kasi.re.kr/kor/life/post/calendarData?year=2026"
MPM = "인사혁신처 보도자료 2026-04-29 https://www.mpm.go.kr/mpm/comm/newsPress/newsPressRelease/?cntId=4250&mode=view"
pred_hol = pd.DataFrame([
    ("2026-07-17", "제헌절", "법정(2026 재지정)", MPM),
    ("2026-08-15", "광복절", "법정", KASI26),
    ("2026-08-17", "대체공휴일(광복절)", "대체", KASI26),
    ("2026-09-24", "추석 연휴", "법정", KASI26),
    ("2026-09-25", "추석", "법정", KASI26),
    ("2026-09-26", "추석 연휴", "법정", KASI26),
    ("2026-10-03", "개천절", "법정", KASI26),
    ("2026-10-05", "대체공휴일(개천절)", "대체", KASI26),
    ("2026-10-09", "한글날", "법정", KASI26),
], columns=["date", "holiday_name", "kind", "source"]).assign(date=lambda d: pd.to_datetime(d.date))
hol = pd.concat([hol, pred_hol], ignore_index=True).sort_values("date")
assert not hol.date.duplicated().any()
hol.to_csv(OUT / "holidays.csv", index=False, encoding="utf-8-sig")

cal = pd.DataFrame({"date": DATES})
cal["dow"] = cal.date.dt.dayofweek
cal["is_weekend"] = (cal.dow >= 5).astype(int)
cal = cal.merge(hol[["date", "holiday_name", "kind"]].rename(columns={"kind": "holiday_kind"}), on="date", how="left")
cal["is_holiday"] = cal.holiday_name.notna().astype(int)
cal["is_offday"] = ((cal.is_weekend == 1) | (cal.is_holiday == 1)).astype(int)
cal["is_seollal"] = cal.holiday_name.fillna("").str.contains("설").astype(int)
cal["is_chuseok"] = cal.holiday_name.fillna("").str.contains("추석").astype(int)
# 연휴 블록: 연속 휴일 길이와 블록 안 위치
blk = (cal.is_offday != cal.is_offday.shift()).cumsum()
cal["offday_block_len"] = np.where(cal.is_offday == 1, cal.groupby(blk).is_offday.transform("size"), 0)
cal["offday_block_pos"] = np.where(cal.is_offday == 1, cal.groupby(blk).cumcount() + 1, 0)
# 앞뒤 휴일까지 거리 (기간 밖은 주말 규칙으로 충분하므로 7로 자름)
off_dates = cal.loc[cal.is_offday == 1, "date"].to_numpy()
idx_next = np.searchsorted(off_dates, cal.date.to_numpy(), side="right")
idx_prev = np.searchsorted(off_dates, cal.date.to_numpy(), side="left") - 1
cal["days_to_next_offday"] = [((off_dates[i] - d) / np.timedelta64(1, "D")) if i < len(off_dates) else 7 for i, d in zip(idx_next, cal.date.to_numpy())]
cal["days_from_prev_offday"] = [((d - off_dates[i]) / np.timedelta64(1, "D")) if i >= 0 else 7 for i, d in zip(idx_prev, cal.date.to_numpy())]
cal[["days_to_next_offday", "days_from_prev_offday"]] = cal[["days_to_next_offday", "days_from_prev_offday"]].clip(upper=7).astype(int)
# 징검다리 평일: 앞날·다음날이 모두 휴일인 평일 (2025-01-31, 2025-10-10, 2026-01-02 등)
cal["is_bridge_day"] = ((cal.is_offday == 0) & (cal.days_to_next_offday == 1) & (cal.days_from_prev_offday == 1)).astype(int)
# 공휴일은 아니지만 수요가 공휴일처럼 줄어든 날 (학습 데이터로 확인: 평소의 0.73배)
cal["is_quasi_holiday"] = cal.date.isin(pd.to_datetime(["2025-05-01"])).astype(int)
cal["is_long_holiday"] = (cal.offday_block_len >= 3).astype(int)
issue("공휴일", "예측 기간(7~10월) 공휴일 9일이 팀 공휴일 CSV에 없음 (학습 기간 31일만)",
      "한국천문연구원 2026 달력·인사혁신처 보도자료 기준으로 추가 (팀 '7~10월 외부 요인' 표와 같음)")
issue("공휴일", "2025-05-01 근로자의 날은 공휴일이 아니지만 승차가 평소의 0.73배",
      "is_quasi_holiday=1로 따로 표시 (2026-05-01은 공휴일)")
note_bridge = ", ".join(cal.loc[cal.is_bridge_day == 1, "date"].dt.strftime("%Y-%m-%d"))
issue("공휴일", f"휴일 사이 평일(징검다리) {note_bridge}", "is_bridge_day로 표시 (2025-10-10은 평소의 0.79배)")

# =====================================================================
# 2. 날씨 (Open-Meteo, CC BY 4.0)
# =====================================================================
w = rd("external/weather_hourly.csv", parse_dates=["date"])
assert len(w) == len(DATES) * 24 and not w.duplicated(["date", "hour"]).any() and w.notna().all().all()
w = w.sort_values(["date", "hour"]).reset_index(drop=True)
w["precip_prev3h"] = w.precip_mm.rolling(3, min_periods=1).sum().shift(1).fillna(0)  # 직전 3시간 강수 (날짜 넘어 이어짐)
w["is_rain"] = (w.precip_mm >= 0.5).astype(int)
w[w.hour.isin(HOURS)].to_csv(OUT / "weather_hourly.csv", index=False, encoding="utf-8-sig")
wd = w.groupby("date").agg(
    precip_day=("precip_mm", "sum"), rain_hours=("is_rain", "sum"), temp_max=("temp_c", "max"),
    temp_min=("temp_c", "min"), temp_mean=("temp_c", "mean"), snow_day=("snow_cm", "sum")).reset_index()
wd6 = w[w.hour.isin(HOURS)].groupby("date").precip_mm.sum().rename("precip_6_23").reset_index()
cal = cal.merge(wd, on="date").merge(wd6, on="date")
cal["precip_prev_day"] = cal.precip_day.shift(1).fillna(0)
issue("날씨", "날씨 파일 2개(시간별·일별) 일강수 차이 최대 19.7mm (상관 0.98, 좌표가 조금 다름)",
      "SOURCES.md에 기록된 시간별 파일(37.46N 126.70E)만 사용, 일별 값은 시간별에서 계산")

# =====================================================================
# 3. 방학 (NEIS)
# =====================================================================
v = rd("external/school_vacation_daily.csv", parse_dates=["date"])
vac_cols = ["vac_elem", "vac_middle", "vac_high", "vac_all"]
v["vac_estimated"] = 0
early = v.date < pd.Timestamp("2025-03-03")
src = v.set_index("date")[vac_cols]
v.loc[early, vac_cols] = src.reindex(v.loc[early, "date"] + pd.Timedelta(days=364)).to_numpy()  # 1년 뒤 같은 요일 값
v.loc[early, "vac_estimated"] = 1
cal = cal.merge(v, on="date", how="left")
issue("방학", "school_vacation_daily의 2025-01-01~03-02가 모두 0 (NEIS 원자료가 2025-03-03부터라 겨울방학이 빠짐)",
      "2026년 같은 요일(+364일) 값으로 채우고 vac_estimated=1")
issue("방학", "SOURCES.md의 calendar_features.csv(인천대 학기 univ_semester)가 폴더에 없음", "이번 정리에서 제외. 파일을 주시면 추가")

# 인천대 학기 (인천대 학사일정, 팀 calendar_features.csv에서 univ_semester만 사용)
cf = rd("cal/calendar_features.csv", parse_dates=["date"])
cal = cal.merge(cf[["date", "univ_semester"]], on="date", how="left")
assert cal.univ_semester.notna().all()
issue("인천대 학기", "calendar_features.csv가 2026-09-28을 대체공휴일로 표시 (월력요항상 평일), 2025-05-01을 공휴일로 표시",
      "학기(univ_semester)만 가져오고 공휴일은 정리본 기준 유지. 2026-2학기 9/1 개강은 인천대 수강신청편람(정정기간 9/1~)과 일치")

# =====================================================================
# 4. 검단 인구 (행정안전부 주민등록, 월말 기준)
# =====================================================================
p = rd("external/gumdan_population_monthly.csv")
p = p[p.dong == "검단합계"][["month", "population_adj", "households"]]
p["date"] = pd.to_datetime(p.month) + pd.offsets.MonthEnd(0)
s = p.set_index("date").population_adj.reindex(pd.date_range("2024-12-31", END)).interpolate(limit_area="inside").bfill()
cal["gumdan_pop_k"] = (cal.date.map(s) / 1000).round(3)
issue("검단 인구", "아라동이 2025-07에 아라1·2동으로 나뉘고 당하동 경계가 바뀌어 동별 합계가 튐",
      "팀이 만든 경계 보정 합계(검단합계 population_adj)만 쓰고 월말 값을 날짜별로 선형 보간")

# =====================================================================
# 5. 역 정적 정보
# =====================================================================
ops_st = rd("opszip/out/ops_station_static.csv")
grp = rd("SINCON_데이터_CSV/02_환승역_증가일·외부요인/전체_역_구분.csv")
opn = rd("SINCON_데이터_CSV/05_역_개통일/station_open_dates.csv")
EXT = {"인천1호선 ↔ 공항철도": 1, "인천2호선 ↔ 공항철도": 1, "인천1호선 ↔ 수도권1호선(경인선)": 2,
       "인천2호선 ↔ 수도권1호선(경인선)": 2, "인천1호선 ↔ 수인분당선": 3, "서울7호선 ↔ 서해선": 4}
st = meta.rename(columns={"canonical_line": "line"})[["station_id", "station_name", "line"]]
st = st.merge(ops_st[["station_id", "order_idx", "n_stations_line", "rel_position", "cum_km_from_end_a",
                      "cum_min_from_end_a", "seg_km_from_prev", "is_terminal_now", "was_terminal_until_20250627"]], on="station_id")
order = st.sort_values(["line", "order_idx"])
st["prev_station"] = st.station_id.map(dict(zip(order.station_id, order.groupby("line").station_id.shift(1)))).fillna(0).astype(int)
st["next_station"] = st.station_id.map(dict(zip(order.station_id, order.groupby("line").station_id.shift(-1)))).fillna(0).astype(int)
g = grp.set_index("station_id")
st["is_transfer"] = st.station_id.map(g["구분"].eq("환승역")).fillna(False).astype(int)
st["transfer_pair"] = st.station_id.map(g["환승 상대 station_id"]).fillna(0).astype(int)
st["transfer_ext_line"] = st.station_id.map(g["환승 노선"].map(EXT)).fillna(0).astype(int)  # 1 공항철도 2 경인선 3 수인분당 4 서해선
st["open_date"] = st.station_id.map(opn.set_index("station_id").open_date)
st.to_csv(OUT / "station_static.csv", index=False, encoding="utf-8-sig")
assert len(st) == 71 and st.open_date.notna().all()

# =====================================================================
# 6. 행사 통합 (경기·공연·축제)
# =====================================================================
WEAK = ["ktriptips", "telltrip", "month2k", "xn--", "스테이지픽", "팬마음", "나무위키", "soapcentral"]
OFFICIAL = ["go.kr", "kleague", "koreabaseball", "KBO", "ictr", "nol.yanolja", "NOL티켓", "티켓링크", "위버스", "KOPIS", "연수구청", "문체부"]


def grade(src):
    """출처 문자열을 매체 단위로 나눠 가장 높은 등급을 돌려준다 (URL은 통째로 한 매체)"""
    outlets = []
    for seg in re.split(r" \| |;", str(src)):
        seg = seg.strip()
        if not seg:
            continue
        outlets += [seg] if seg.startswith("http") else [x.strip() for x in seg.split("/") if x.strip()]
    gs = [0 if any(k in x for k in WEAK) else 2 if any(k in x for k in OFFICIAL) else 1 for x in outlets]
    return {2: "official", 1: "news", 0: "weak"}[max(gs) if gs else 0]


def hhmm(x):
    if pd.isna(x) or str(x).strip() == "":
        return np.nan
    a = str(x).split("~")[0]
    h, m = a.split(":")
    return int(h) + int(m) / 60


def hend(x):
    return hhmm(str(x).split("~")[1]) if isinstance(x, str) and "~" in x else np.nan


rows = []
# 6-1 SSG 문학 홈경기 (KBO 공식 박스스코어: 실제 개시·종료 시각, 관중. 정규·포스트시즌·시범경기)
#     출처: KBO 게임센터 https://www.koreabaseball.com/Schedule/GameCenter/Main.aspx (조회일 2026-11-12)
kr = rd("kbo/kbo_munhak_games_raw.csv", dtype=str)


def _hm(x):
    if pd.isna(x) or not str(x).strip():
        return np.nan
    h, m = str(x).split(":")
    return int(h) + int(m) / 60


kr["start_h"] = kr.start_tm.map(_hm)
kr["end_h"] = kr.end_tm.map(_hm)
kr["sched_h"] = kr.sched_time.map(_hm)
kr["crowd"] = pd.to_numeric(kr.crowd, errors="coerce")
kr["played"] = (kr.cancel == "정상경기").astype(int)
for d, gg in kr.groupby("date"):
    pl = gg[gg.played == 1]
    gtype = gg.game_type.iloc[0]
    kind_scale = 1 if gtype == "시범경기" else 3 if "PO" in gtype else 2
    rows.append(dict(date=f"{d[:4]}-{d[4:6]}-{d[6:]}", station_id=3127, kind="kbo",
                     name=f"SSG {'시범경기' if gtype == '시범경기' else '홈경기'} vs {gg.away.iloc[0]}",
                     start_hour=pl.start_h.min() if len(pl) else gg.sched_h.min(),
                     end_hour=pl.end_h.max() if len(pl) else np.nan,
                     attendance=pl.crowd.sum() if len(pl) else np.nan, scale=kind_scale, played=int(len(pl) > 0),
                     n_games=len(pl), source="KBO 게임센터 박스스코어 https://www.koreabaseball.com/Schedule/GameCenter/Main.aspx",
                     date_status="confirmed", note=f"{gtype}; " + ";".join(sorted(set(gg.cancel)))))
ssg = rd("external/ssg_home_games_2025_2026.csv")
assert set(ssg.date.str.replace("-", "")) <= set(kr.date), "SSG 일정 불일치"
issue("SSG 경기", "기존 일정 파일에 시범경기 14건(2025-03-10~16, 2026-03-16~24)이 빠져 있고 종료 시각·관중이 없었음",
      "KBO 게임센터 박스스코어로 178건(정규 160·포스트시즌 3·시범 14 + 취소 포함) 실제 개시·종료 시각과 관중 반영. "
      "기존 164건과 날짜·상대팀·취소 여부·예정 시각 모두 일치. 2026 SSG는 포스트시즌 없음")

# 6-2 부천FC (K리그 공식 + 컵대회 언론), 관중 포함 events_all 기준
ea = rd("events_all_2023_2026.csv")
ea = ea[(ea.date >= "2025-01-01") & (ea.date <= "2026-10-31")]
bfc = ea[ea["구분"] == "부천FC 홈경기"]
for r in bfc.itertuples():
    att = pd.to_numeric(r._8, errors="coerce")
    st_h = hhmm(r.시작시간)
    rows.append(dict(date=r.date, station_id=3754, kind="kleague", name=r.행사명, start_hour=st_h,
                     end_hour=st_h + 2 if not np.isnan(st_h) else np.nan, attendance=att, scale=1, played=1, n_games=1,
                     source=r.출처, date_status="confirmed", note=str(r.비고)))
ext_b = rd("external/bucheon_fc_home_games.csv")
assert set(ext_b.date) <= set(bfc.date), "부천FC 목록 불일치"
issue("부천FC", "external 목록(38경기)에 코리아컵·승강PO·오픈트레이닝 7건이 빠져 있음", "events_all(45경기, 관중 포함)을 기준으로 사용. 시작 시각은 두 파일이 모두 같음")

# 6-3 공연·축제: events_all + transfer_events + external/events 를 합쳐 중복 제거
KEYS = [("펜타포트", "pentaport", "fest", 3), ("맥주축제", "beerfest", "fest", 2), ("능허대", "neunghuh", "fest", 2),
        ("이슬라이브", "isllive", "concert", 2), ("흠뻑쇼", "psy", "concert", 3), ("SEVENTEEN", "svt", "concert", 3),
        ("Stray", "skz", "concert", 3), ("박효신", "phs", "concert", 3), ("MUSE", "muse", "concert", 3),
        ("YE", "ye", "concert", 3), ("BTS", "jin", "concert", 3), ("PLAVE", "plave", "concert", 3),
        ("Sustainable", "swf", "concert", 3), ("GHOSTIVAL", "ghostival", "concert", 3), ("부천페스타", "bcfesta", "fest", 2),
        ("진달래", "azalea", "fest", 3), ("풍물", "pungmul", "fest", 3), ("워터축제", "araon_water", "fest", 2),
        ("가을꽃", "araon_flower", "season", 2), ("국화", "araon_flower", "season", 2), ("드림파크", "dreampark", "season", 1),
        ("영화 주간", "film_week", "fest", 1)]


def key_of(name):
    for k, code, kind, sc in KEYS:
        if k in name:
            if code == "araon_flower" and "드림파크" in name:
                continue
            return code, kind, sc
    raise ValueError(name)


cand = []
for r in ea[~ea["구분"].eq("부천FC 홈경기")].itertuples():
    code, kind, sc = key_of(r.행사명)
    cand.append(dict(date=r.date, station_id=int(r.station_id), code=code, kind=kind, scale=sc, name=r.행사명,
                     start_hour=hhmm(r.시작시간), end_hour=hend(r.시작시간), source=r.출처, origin="events_all",
                     played=0 if "취소" in r.행사명 else 1, note=str(r.비고)))
te = rd("transfer_events.csv")
for r in te[te.kind != "game"].itertuples():
    code, kind, sc = key_of(r.name)
    for d in pd.date_range(r.start_date, r.end_date):
        for s_id in str(r.station_ids).split():
            cand.append(dict(date=d.strftime("%Y-%m-%d"), station_id=int(s_id), code=code, kind=r.kind, scale=r.scale,
                             name=r.name, start_hour=r.start_time, end_hour=r.end_time, source=r.source,
                             origin="transfer_events", played=1, note=""))
xe = rd("external/events_2025_2026.csv")
for r in xe.itertuples():
    code, kind, sc = key_of(r.event)
    cand.append(dict(date=r.date, station_id=int(r.station_id), code=code, kind=kind, scale=sc, name=r.event,
                     start_hour=hhmm(r.start_time), end_hour=np.nan, source=r.source, origin="external", played=1, note=""))
cand = pd.DataFrame(cand)
cand = cand[(cand.date >= "2025-01-01") & (cand.date <= "2026-10-31")]
cand["gr"] = cand.source.map(grade).map({"official": 2, "news": 1, "weak": 0})
# 같은 (날짜, 역, 행사)는 하나로: 출처 등급이 높은 행 우선, 시각은 있는 값으로 채움
cand = cand.sort_values(["date", "station_id", "code", "gr"], ascending=[True, True, True, False])
agg = cand.groupby(["date", "station_id", "code"]).agg(
    kind=("kind", "first"), scale=("scale", "max"), name=("name", "first"), start_hour=("start_hour", "first"),
    end_hour=("end_hour", "first"), source=("source", lambda x: " | ".join(dict.fromkeys(x))),
    origin=("origin", lambda x: ",".join(sorted(set(x)))), played=("played", "min"), note=("note", "first"),
    gr=("gr", "max")).reset_index()
agg["attendance"] = np.nan
agg["n_games"] = 0
agg["date_status"] = "confirmed"
agg.loc[agg.name.str.contains("추정"), "date_status"] = "estimated"
agg.loc[(agg.code == "araon_flower") & (agg.date >= "2026"), "date_status"] = "estimated"
ev = pd.concat([pd.DataFrame(rows).assign(code=lambda d: d.kind, origin="games",
                                          gr=lambda d: d.source.map(grade).map({"official": 2, "news": 1, "weak": 0})),
                agg], ignore_index=True)
ev["source_grade"] = ev.gr.map({2: "official", 1: "news", 0: "weak"})
ev = ev.drop(columns="gr")
# 같은 날 같은 역 문학 공연 + 같은 날 SSG 경기 등은 그대로 두고 일 단위 피처에서 합침

# 학습 기간 효과: 역 하루 승차 / 같은 역·요일 앞뒤 5주 중앙값 / 그날 전체 비율
tr = pd.read_csv(RAW / "train.csv", parse_dates=["date"])
sd = tr.groupby(["station_id", "date"]).boardings.sum().reset_index()
sd["dow"] = sd.date.dt.dayofweek
sysd = tr.groupby("date").boardings.sum()
sysd_ref = sysd.groupby(sysd.index.dayofweek).transform(lambda x: x.rolling(11, center=True, min_periods=3).median())
sd["sys_ratio"] = sd.date.map(sysd / sysd_ref)
sd = sd.sort_values(["station_id", "dow", "date"])
sd["ref"] = sd.groupby(["station_id", "dow"]).boardings.transform(lambda x: x.rolling(11, center=True, min_periods=3).median())
sd["effect"] = (sd.boardings / sd.ref / sd.sys_ratio).round(2)
ev["date"] = pd.to_datetime(ev.date)
ev = ev.merge(sd[["station_id", "date", "effect"]].rename(columns={"effect": "train_effect"}), on=["station_id", "date"], how="left")
ev["use_default"] = 1
ev.loc[ev.played == 0, "use_default"] = 0
ev.loc[ev.source_grade == "weak", "use_default"] = 0
CONFLICT = (ev.code == "neunghuh") & (ev.station_id == 3128)
ev.loc[CONFLICT, "use_default"] = 0
ev.loc[ev.code == "film_week", "use_default"] = 0
# 부평풍물대축제: 공식 출처로 교체 (조회일 2026-11-12)
PF25 = "부평구 제29회 부평풍물대축제 프로그램북 https://portal.icbp.go.kr/bpf/program/2025/pungmul2025.pdf"
PF26 = ("인천광역시 게시글 2026-09-27 https://www.incheon.go.kr/moo/MOO020101/3089203 ; "
        "인천시 인터뷰 2026-09-08 https://www.incheon.go.kr/goodmorning/GM050100/3087388")
pf = ev.code == "pungmul"
ev.loc[pf & (ev.date.dt.year == 2025), "source"] = PF25
ev.loc[pf & (ev.date.dt.year == 2026), "source"] = PF26
ev.loc[pf, "source_grade"] = "official"
ev.loc[pf, "use_default"] = 1
first_day = pf & ev.date.isin(pd.to_datetime(["2025-09-26", "2026-10-02"]))
ev.loc[first_day, "use_default"] = 0
ev.loc[first_day, "note"] = "첫날: 2025년은 신트리공원 개막, 2026년은 부평대로 행사가 10/3~4 → 역 영향 불확실"
issue("행사 출처", "부평풍물대축제 출처가 비공식 정보 사이트(ktriptips)뿐이었음",
      "부평구 2025 프로그램북·인천시 2026 게시글로 교체. 부평대로 행사일(2025-09-27~28, 2026-10-03~04)만 사용, "
      "첫날은 제외 (학습 효과: 첫날 1.00배, 부평대로 날 1.19~1.28배)")
# 해마다 같은 기준으로 넣을 수 없는 행사는 학습·예측 모두 끔 (한쪽만 켜면 모델이 효과를 잘못 배움)
for code, why in [("araon_flower", "2026 일정 미발표(추정 날짜·비공식 출처), 2025 학습 효과도 1.07배로 작음"),
                  ("dreampark", "2025 출처가 비공식 집계 사이트, 학습 효과 1.06배로 작음")]:
    ev.loc[ev.code == code, "use_default"] = 0
    issue("행사 제외", f"{code}: {why}", "학습·예측 모두 use_default=0")
ev["is_exhibition"] = ev.name.str.contains("시범경기").astype(int)
ev = ev.sort_values(["date", "station_id", "kind"]).reset_index(drop=True)
cols = ["date", "station_id", "kind", "code", "name", "start_hour", "end_hour", "scale", "attendance", "played", "n_games", "is_exhibition",
        "date_status", "source_grade", "use_default", "train_effect", "origin", "source", "note"]
ev[cols].to_csv(OUT / "events.csv", index=False, encoding="utf-8-sig")

weak = ev[ev.source_grade == "weak"].groupby(["code", "station_id"]).agg(d0=("date", "min"), d1=("date", "max"), eff=("train_effect", "mean")).reset_index()
for r in weak.itertuples():
    issue("행사 출처", f"{r.code} 역 {r.station_id} {r.d0.date()}~{r.d1.date()} 출처가 비공식 정보 사이트뿐 (학습 효과 평균 {r.eff if not np.isnan(r.eff) else '-'})",
          "use_default=0 (공식·언론 출처를 찾으면 1로)")
issue("행사 충돌", "2026 연수 능허대 문화축제: 행사 일정 시트는 '연수한마음공원이라 제외', 환승 피처는 선학역(3128)에 연결",
      "선학역 행은 use_default=0")
issue("행사 출처", "SOURCES.md는 PLAVE 콘서트를 '블로그로만 확인'이라 제외했지만 events_all은 위버스 공지·NOL티켓 출처로 다시 넣음",
      "공식 출처가 있어 사용 (use_default=1)")
issue("행사 날짜", "2025 원미산 진달래축제(4/5~6), 2026 계양아라온 가을꽃(9/19~10/31)은 추정 날짜",
      "date_status=estimated. 2026 드림파크 국화축제(10/16~25)는 헤럴드경제 보도로 확인됨")
issue("행사 제외", "송도해변축제(2026-08-08~15)는 장소가 송도달빛축제공원인지 불분명, 2025-05-31 칸예 공연은 취소",
      "송도해변축제는 넣지 않음, 칸예 취소는 played=0으로 남김")

# 시간대 펼치기 (행사장 역만). 진행: 시작 1시간 전~종료 전, 귀가: 종료 시각과 그 다음 1시간
# 기본값은 학습 기간 승차 정점으로 맞춤: 공연은 시작 후 약 3.5시간 뒤 귀가 정점(박효신 18:20→21~22시, SVT 18:30→22~23시),
# 시작 시각을 모르는 공연은 휴일 18시·평일 19시. 축구는 시작+2시간, 야구는 +3.25시간, 축제는 11~21시
offday_set = set(cal.loc[cal.is_offday == 1, "date"])
DUR = {"kbo": 3.25, "kleague": 2.0, "concert": 3.5}
hr = []
for r in ev[ev.played == 1].itertuples():
    off = r.date in offday_set
    s0 = r.start_hour if not pd.isna(r.start_hour) else {"kbo": 18.5, "kleague": 19.0, "concert": 18.0 if off else 19.0,
                                                         "fest": 11.0, "season": 10.0}[r.kind]
    if not pd.isna(r.end_hour):
        e0 = r.end_hour
    elif r.kind in DUR:
        e0 = s0 + DUR[r.kind]
    else:
        e0 = 21.0 if r.kind == "fest" else 18.0
    on = [h for h in range(int(np.floor(s0)) - 1, int(np.floor(e0))) if h in HOURS]
    ex = [] if r.kind == "season" else [h for h in (int(np.floor(e0)), int(np.floor(e0)) + 1) if h in HOURS]
    for h in on:
        hr.append((r.date, r.station_id, h, r.kind, 1, 0, r.use_default))
    for h in ex:
        hr.append((r.date, r.station_id, h, r.kind, 0, 1, r.use_default))
eh = pd.DataFrame(hr, columns=["date", "station_id", "hour", "kind", "evt_on", "evt_exit", "use_default"])
eh = eh.groupby(["date", "station_id", "hour", "kind"]).max().reset_index()
eh.to_csv(OUT / "events_hourly.csv", index=False, encoding="utf-8-sig")

# =====================================================================
# 7. 운영 시각표 (인천교통공사)
# =====================================================================
tt = rd("opszip/out/ops_timetable_hourly.csv")
grid = pd.MultiIndex.from_product([DATES, STATIONS, HOURS], names=["date", "station_id", "hour"]).to_frame(index=False)
offd = set(cal.loc[cal.is_offday == 1, "date"])
grid["timetable_type"] = np.where(grid.date.isin(offd), "sat_holiday", "weekday")
tcols = ["tt_trains_dir_a", "tt_trains_dir_b", "tt_trains_total", "tt_headway_min"]
o = grid.merge(tt[["station_id", "timetable_type", "hour"] + tcols], on=["station_id", "timetable_type", "hour"], how="left")
is_l1 = o.station_id.between(3107, 3139)
before_ext, before_hw = o.date < "2025-06-28", o.date < "2025-04-12"
m = is_l1 & before_hw & (o.timetable_type == "weekday")
f = pd.Series(9 / 8.5, index=o.index)
f[o.hour.isin([7, 8])] = 5 / 4.5
f[o.hour.isin([18, 19])] = 1.0
for c in tcols[:3]:
    o.loc[m, c] = o.loc[m, c] * f[m]
o.loc[m, "tt_headway_min"] = o.loc[m, "tt_headway_min"] / f[m]
closed = before_ext & o.station_id.isin([3107, 3108, 3109])
o.loc[closed, tcols[:3]] = 0.0
o.loc[closed, "tt_headway_min"] = np.nan
gy = before_ext & (o.station_id == 3110)
o.loc[gy, "tt_trains_total"] = o.loc[gy, "tt_trains_dir_b"]
o.loc[gy, "tt_trains_dir_a"] = 0.0
o.loc[gy, "tt_headway_min"] = 60 / o.loc[gy, "tt_trains_dir_b"]
o["tt_estimated"] = (is_l1 & before_ext).astype(int)
o = o.drop(columns="timetable_type")
o[tcols] = o[tcols].round(3)
assert o.tt_trains_total.notna().all()
o.to_csv(OUT / "ops_hourly.csv", index=False, encoding="utf-8-sig")
issue("운영", "장애 기록이 2026-04 이후 6건뿐(2025년은 미수집), 특별교통대책·심야 연장도 2026년만 있고 2026-09-26~27 추석 심야 연장은 빠짐",
      "학습·예측 기간에 같은 기준으로 모인 자료가 아니라 피처에서 제외. 시각표(공식)만 사용")
issue("운영", "admin_gu_from_20260701, renamed_20260701은 학습 기간 값이 없음", "제외")

# =====================================================================
# 8. 검단 입주 (역별 누적 세대, 60일 선형 입주 가정)
# =====================================================================
mv = rd("geomdan_move_ins.csv", parse_dates=["move_in_start"])
mv = mv[mv.status.isin(["confirmed", "planned", "estimated"]) & mv.station_id.notna()]
gd = []
for r in mv.itertuples():
    sts = [int(r.station_id)] + ([int(r.station_id_2)] if not pd.isna(r.station_id_2) else [])
    frac = np.clip((DATES - r.move_in_start).days / 60, 0, 1)
    for s_id in sts:
        gd.append(pd.DataFrame({"date": DATES, "station_id": s_id, "units": r.units * frac / len(sts),
                                "units_confirmed": r.units * frac / len(sts) * (r.status == "confirmed")}))
gd = pd.concat(gd).groupby(["date", "station_id"]).sum().reset_index()
gd = gd.rename(columns={"units": "movein_units_cum", "units_confirmed": "movein_units_cum_confirmed"})
gd[["movein_units_cum", "movein_units_cum_confirmed"]] = gd[["movein_units_cum", "movein_units_cum_confirmed"]].round(1)
gd.to_csv(OUT / "geomdan_station_daily.csv", index=False, encoding="utf-8-sig")
issue("검단 입주", "SOURCES.md는 입주 일정을 '블로그 출처'로 제외했지만 geomdan_move_ins.csv는 언론·공식 출처로 다시 정리됨. 'planned'는 2022~2024년 분양 당시 예정월",
      "unverified 2건·역 미상 5건 제외. 확정만 쓰는 열(movein_units_cum_confirmed)을 따로 둠. 인구(공식 통계)를 우선 권장")

# =====================================================================
# 9. 과거 월보 (2023·2024 7~10월, 인천교통공사)
# =====================================================================
mb = rd("SINCON_데이터_CSV/03_과거3개년_7-10월_승차/월별_역·시간대_합계.csv")
mb = mb[mb["출처"].str.contains("월보")]
hcols = [f"{h:02d}시" for h in HOURS]
mb = mb.melt(id_vars=["연도", "월", "일수", "station_id"], value_vars=hcols, var_name="hour", value_name="boardings_month")
mb["hour"] = mb.hour.str[:2].astype(int)
mb = mb.rename(columns={"연도": "year", "월": "month", "일수": "days"})
mb["boardings_per_day"] = (mb.boardings_month / mb.days).round(2)
mb.to_csv(OUT / "past_monthly_boardings.csv", index=False, encoding="utf-8-sig")
issue("과거 월보", "월별 합계 파일의 2025년 행은 공사 월보가 아니라 대회 train.csv 합계 (출처 열로 구분됨)",
      "2023·2024 월보만 남김. 2025는 train.csv에서 직접 계산할 것")

# =====================================================================
# 10. 저장
# =====================================================================
cal.to_csv(OUT / "calendar_daily.csv", index=False, encoding="utf-8-sig")
pd.DataFrame(issues).to_csv(OUT / "data_issues.csv", index=False, encoding="utf-8-sig")
for name in ["calendar_daily", "weather_hourly", "events", "events_hourly", "station_static", "ops_hourly",
             "geomdan_station_daily", "past_monthly_boardings", "holidays", "data_issues"]:
    d = pd.read_csv(OUT / f"{name}.csv")
    print(f"{name:26s} {d.shape}")
