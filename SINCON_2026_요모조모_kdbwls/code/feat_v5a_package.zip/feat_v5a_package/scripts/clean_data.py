"""SINCON 2026 - 1단계 데이터 정리 (Dacon 버스 대회 수상팀 방식 적용)

사용법: python clean_data.py <원본 폴더(train.csv 등)> <출력 폴더>

출력
  combined.parquet : train+test를 합친 표 (3위팀 combined 방식) + 정리된 키·플래그
  anomaly_log.csv  : 이상치로 표시된 역·날짜 목록과 이유
  clean_report.txt : 점검 결과 요약

원칙: 원본 boardings는 바꾸지 않는다. 정리 결과는 플래그·가중치·보정열로만 추가한다.
      모든 데이터 기반 플래그는 train(2026-06-30까지) 기록으로만 계산한다.
"""
import re
import sys
from pathlib import Path

import numpy as np
import pandas as pd

RAW, OUT = Path(sys.argv[1]), Path(sys.argv[2])
OUT.mkdir(parents=True, exist_ok=True)
CUTOFF = pd.Timestamp("2026-06-30")
HOURS = list(range(6, 24))
log = []


def note(msg):
    print(msg)
    log.append(msg)


# ---------------------------------------------------------------- 1. 불러오기·기본 점검
tr = pd.read_csv(RAW / "train.csv", parse_dates=["date"])
te = pd.read_csv(RAW / "test.csv", parse_dates=["date"])
ss = pd.read_csv(RAW / "sample_submission.csv")
md = pd.read_csv(RAW / "metaData.csv", parse_dates=["first_date", "last_date"])

note(f"train {tr.shape} {tr.date.min().date()}~{tr.date.max().date()} / test {te.shape} {te.date.min().date()}~{te.date.max().date()}")
assert tr[["boardings", "alightings"]].notna().all().all(), "결측 있음"
assert (tr[["boardings", "alightings"]] >= 0).all().all(), "음수 있음"
assert not tr.duplicated(["date", "station_id", "hour"]).any(), "train 키 중복"
assert not te.duplicated(["date", "station_id", "hour"]).any(), "test 키 중복"
assert set(tr.hour) == set(te.hour) == set(HOURS)

# 2위팀: train/test 양쪽에 있는 범주만 사용 -> SINCON은 71역 모두 양쪽에 있음
s_tr, s_te, s_md = set(tr.station_id), set(te.station_id), set(md.station_id)
note(f"역 수 train/test/meta = {len(s_tr)}/{len(s_te)}/{len(s_md)}, 한쪽에만 있는 역: {sorted((s_tr ^ s_te) | (s_md ^ s_tr))}")

# 운영 기간 격자 완전성 (역별 first_date~6/30 x 18시간)
grid = pd.concat(
    pd.MultiIndex.from_product(
        [pd.date_range(r.first_date, min(r.last_date, CUTOFF)), [r.station_id], HOURS],
        names=["date", "station_id", "hour"],
    ).to_frame(index=False)
    for r in md.itertuples()
)
missing = len(grid.merge(tr, how="left", on=["date", "station_id", "hour"]).query("boardings.isna()"))
note(f"운영 기간 격자 {len(grid):,}행 중 빠진 행 {missing}, train 행 {len(tr):,}")

# 제출 양식 점검: zip 안의 sample_submission은 7~9월뿐
miss_ss = te.loc[~te.example_id.isin(ss.example_id)]
if len(miss_ss):
    note(f"[주의] sample_submission {len(ss):,}행 < test {len(te):,}행. 빠진 날짜 "
         f"{miss_ss.date.min().date()}~{miss_ss.date.max().date()} -> 제출 파일은 test.csv의 example_id로 만들 것")

# ---------------------------------------------------------------- 2. 합치기 (3위팀 combined)
tr["is_test"] = 0
te["is_test"] = 1
df = pd.concat([tr, te], ignore_index=True)

# ---------------------------------------------------------------- 3. 이름·키 정리 (2위팀 cleaning/combine)
md["station_name_base"] = md.station_name.map(lambda s: re.sub(r"\(.*?\)", "", s).strip())
md["n_lines_same_name"] = md.groupby("station_name_base").station_id.transform("count")
md = md.rename(columns={"canonical_line": "line"})
df = df.merge(md[["station_id", "station_name", "station_name_base", "line", "first_date", "n_lines_same_name"]],
              on="station_id", how="left")
shared = md.loc[md.n_lines_same_name > 1].groupby("station_name_base").station_id.apply(list).to_dict()
note(f"같은 이름의 다른 노선 역(환승 묶음): {shared}")

df["dow"] = df.date.dt.dayofweek.astype("int8")
df["dow_type"] = np.select([df.dow == 5, df.dow == 6], [1, 2], 0).astype("int8")  # 0평일 1토 2일 (공휴일은 팀 달력으로 덮어씀)
df["station_hour"] = df.station_id.astype(str) + "_" + df.hour.astype(str)
df["station_dowtype_hour"] = df.station_hour + "_" + df.dow_type.astype(str)
df["line_hour"] = df.line.astype(str) + "_" + df.hour.astype(str)
df["complex_hour"] = df.station_name_base + "_" + df.hour.astype(str)
for c in ["station_hour", "station_dowtype_hour", "line_hour", "complex_hour"]:
    df[c] = df[c].astype("category")

# 신규 역 (검단 3역): 개통 후 경과일, 개통 첫 주
df["days_since_open"] = (df.date - df.first_date).dt.days.astype("int32")
df["is_new_station"] = (df.first_date > pd.Timestamp("2025-01-01")).astype("int8")
df["is_open_week"] = ((df.is_new_station == 1) & (df.days_since_open < 7)).astype("int8")

# ---------------------------------------------------------------- 4. 이상치 표시 (train만, 원본은 그대로)
t = df.is_test == 0
day_sys = df[t].groupby("date").boardings.sum().rename("sys").reset_index()
day_sys["dow"] = day_sys.date.dt.dayofweek


def same_dow_median(frame, val, keys):
    """같은 키·같은 요일의 앞뒤 5주(자기 자신 제외) 중앙값"""
    out = np.full(len(frame), np.nan)
    frame = frame.reset_index(drop=True)
    for _, g in frame.groupby(keys + ["dow"]):
        v = g[val].to_numpy(float)
        d = g.date.to_numpy()
        for i in range(len(g)):
            m = (np.abs(d - d[i]) <= np.timedelta64(35, "D")) & (np.arange(len(g)) != i)
            out[g.index[i]] = np.median(v[m]) if m.any() else np.nan
    return out


day_sys["ref"] = same_dow_median(day_sys, "sys", [])
day_sys["sys_ratio"] = day_sys.sys / day_sys.ref
low_days = day_sys.loc[day_sys.sys_ratio < 0.85, "date"]
note(f"전체 승차가 같은 요일 대비 85% 미만인 날 {len(low_days)}일 (대부분 공휴일·명절, 팀 공휴일 목록과 대조용)")

sd = df[t].groupby(["station_id", "date"])[["boardings", "alightings"]].sum().reset_index()
sd["dow"] = sd.date.dt.dayofweek
sd["ref_b"] = same_dow_median(sd, "boardings", ["station_id"])
sd["ref_a"] = same_dow_median(sd, "alightings", ["station_id"])
sd["rb"] = sd.boardings / sd.ref_b
sd["ra"] = sd.alightings / sd.ref_a
sd = sd.merge(day_sys[["date", "sys_ratio"]], on="date")
sd["rb_adj"] = sd.rb / sd.sys_ratio  # 그날 전체 수준(공휴일 등)을 뺀 역 고유 변화

# (a) 집계 오류 의심: 승차만 3배 넘게 뛰고 하차는 평소 수준
err = sd[(sd.rb > 3) & (sd.ra.between(0.7, 1.4))].assign(reason="승차만 급증(하차 정상) - 집계 오류 의심")
# (b) 행사성 급증: 그날 전체 대비 역 승차가 1.5배 이상
spike = sd[(sd.rb_adj >= 1.5) & ~sd.set_index(["station_id", "date"]).index.isin(err.set_index(["station_id", "date"]).index)]
spike = spike.assign(reason="역 승차 급증(행사·경기 추정)")
# (c) 역 고유 급감: 그날 전체는 정상인데 역만 60% 미만 (점검 결과 대부분 비 오는 주말·경기 없는 날 -> 실제 변동, 가중치 그대로)
drop = sd[(sd.rb_adj < 0.6) & (sd.sys_ratio > 0.85)].assign(reason="역 승차 급감(비·경기 없는 날 등, 실제 변동)")
# (d) 신규 역 개통 첫 주
ow = df[t & (df.is_open_week == 1)].groupby(["station_id", "date"]).boardings.sum().reset_index().assign(reason="신규 역 개통 첫 주")

alog = pd.concat([err, spike, drop, ow], ignore_index=True)
alog = alog.merge(md[["station_id", "station_name", "line"]], on="station_id")
cols = ["station_id", "station_name", "line", "date", "reason", "boardings", "alightings", "rb", "ra", "sys_ratio", "rb_adj"]
alog["on_sys_low_day"] = alog.date.isin(low_days).astype(int)  # 1이면 공휴일·명절성 날
cols.append("on_sys_low_day")
alog = alog[cols].sort_values(["reason", "station_id", "date"])
alog.round({"rb": 3, "ra": 3, "sys_ratio": 3, "rb_adj": 3}).to_csv(OUT / "anomaly_log.csv", index=False, encoding="utf-8-sig")
note("이상치 표시: " + alog.reason.value_counts().to_string().replace("\n", " | "))

key = ["station_id", "date"]
for name, frame in [("flag_suspect_error", err), ("flag_station_spike", spike), ("flag_station_drop", drop)]:
    df[name] = df.set_index(key).index.isin(frame.set_index(key).index).astype("int8")
df["flag_sys_low_day"] = (df.date.isin(low_days) & t).astype("int8")

# ---------------------------------------------------------------- 5. 학습용 보정열·가중치
# 원본 boardings: 모델 타깃 (행사 급증은 행사 피처로 설명할 대상이라 그대로 둠)
# boardings_robust: 역·시간대 통계(최근 수준, 타깃 평균 등)를 계산할 때 쓰는 값
#   - 집계 오류 의심일은 같은 역·시간·요일 앞뒤 5주 중앙값으로 대체
hr = df[t][["station_id", "hour", "date", "boardings"]].copy()
hr["dow"] = hr.date.dt.dayofweek
bad = df.loc[t & (df.flag_suspect_error == 1), ["station_id", "hour", "date"]]
df["boardings_robust"] = df.boardings.astype(float)
for r in bad.itertuples():
    ref = hr[(hr.station_id == r.station_id) & (hr.hour == r.hour) & (hr.dow == r.date.dayofweek)
             & ((hr.date - r.date).abs() <= pd.Timedelta("35D")) & (hr.date != r.date)].boardings
    df.loc[(df.station_id == r.station_id) & (df.hour == r.hour) & (df.date == r.date), "boardings_robust"] = ref.median()
df.loc[df.is_test == 1, "boardings_robust"] = np.nan

# sample_weight: 집계 오류 0, 개통 첫 주 0.3, 나머지 1
df["sample_weight"] = np.where(df.flag_suspect_error == 1, 0.0, np.where(df.is_open_week == 1, 0.3, 1.0))
df.loc[df.is_test == 1, "sample_weight"] = np.nan

# ---------------------------------------------------------------- 6. 저장
df = df.sort_values(["date", "station_id", "hour"]).reset_index(drop=True)
df.to_parquet(OUT / "combined.parquet", index=False)
note(f"combined.parquet {df.shape} 저장, 열: {list(df.columns)}")
(OUT / "clean_report.txt").write_text("\n".join(log), encoding="utf-8")
