# feat_v5a 피처 묶음 (SINCON 2026, 2026-11-12)

통합 데이터(`sincon_추가데이터 2`)로 외부 자료를 바꾸고 원미산 진달래축제를 유지한 피처 버전입니다.
예측 기간(2026-07~10)의 승하차 수는 어떤 피처에도 쓰지 않았습니다 (대회 규칙 4절).

## 들어 있는 것
| 경로 | 내용 |
|---|---|
| `features/features_A.parquet` | 검증 A: 기준일 2025-06-30, 학습 2025-01-01~06-30 (221,706행), 예측 2025-07-01~10-31 (157,194행, 정답 있음) |
| `features/features_B.parquet` | 검증 B: 기준일 2026-02-28, 학습 2025-01-01~2026-02-28 (532,260행), 예측 2026-03-01~06-30 (155,916행, 정답 있음) |
| `features/features_final.parquet` | 제출용: 기준일 2026-06-30, 학습 688,176행, 예측 2026-07-01~10-31 (157,194행, 정답 없음) |
| `features/feature_list.json` | 피처 138개, 묶음(groups), 범주형 목록, 목표·base·가중치 열 이름 |
| `features/stage1_results.json` | 1차 예측(하루 승차 x 시간대 비중) 단독 점수 |
| `feature_list.csv` | 피처별 묶음·자료형·범주형 여부·최종 모델 사용 여부(126개 사용)·컷별 학습/예측 행 채움 비율 |
| `scripts/` | 만드는 스크립트 전부 + 최종 학습 스크립트 |
| `inputs/` | 스크립트 입력 (정리된 외부 자료 `ext_clean2`, 시간별 날씨, KBO 박스스코어, 대회 자료 정리본 `combined.parquet`) |

### 피처 외 열
`date, station_id, hour, example_id, is_test, is_target(1=예측 행), boardings(예측 행은 비어 있음 또는 검증 정답), y=log1p(boardings), y_dev=y−base(학습 목표), w(가중치), s1_ok, y_res`
- 검증 A·B는 `is_target==1` 행에 정답 `y`가 있습니다. 점수는 `RMSLE = sqrt(mean((예측 log − y)^2))`
- 최종 모델 피처 = `feature_list.csv`의 `used_in_final_model==1` 126개 (1차 예측 5개, 날씨2 일부 7개 제외)

## 다시 만드는 순서 (모두 `python3 -I`, 작업 폴더 기준)
```bash
# 0) 대회 원본(raw/train.csv 등) → combined.parquet  (inputs/clean/combined.parquet 에 이미 있음)
python3 -I scripts/clean_data.py raw clean
# 1) 외부 자료 교체 (기존 ext_clean + 통합 자료 → ext_clean2). inputs/ext_clean2 에 결과가 이미 있음
python3 -I scripts/build_external_v2.py "sincon_추가데이터 2" ext_clean inputs/kbo_munhak_games_raw.csv ext_clean2
# 2) 외부 자료 붙이기
python3 -I scripts/join_external.py inputs/clean/combined.parquet inputs/ext_clean2 clean/combined_ext2.parquet
# 3) 피처 (A, B, final)
DATA_V2=1 KEEP_AZALEA=1 EVENTS_CSV=inputs/ext_clean2/events.csv WEATHER_RAW=inputs/weather_hourly.csv \
  python3 -I scripts/build_features.py clean/combined_ext2.parquet feat_v5a_pre
# 4) 1차 예측 열 추가 → feat_v5a
python3 -I scripts/stage1_baseline.py clean/combined_ext2.parquet inputs/ext_clean2/past_monthly_boardings.csv feat_v5a_pre feat_v5a
```
- 1단계(`build_external_v2.py`)는 기존 `ext_clean`(이전 대화에서 `build_external.py`로 만든 것)이 필요합니다. `inputs/ext_clean2`를 그대로 쓰면 2단계부터 시작하면 됩니다.
- 환경변수: `DATA_V2=1` 취소 경기 피처 추가·입주 일정 제외, `KEEP_AZALEA=1` 원미산 진달래축제 유지

## 검증·제출 모델
- 빠른 확인: `NSEED=3 python3 -I scripts/quick_r0.py feat_v5a B` → B 0.1635, A 0.2964 (전체 학습, 시드 3개)
- 최종: `python3 -I scripts/train_final_kfold.py feat_v5a out raw/test.csv 3 0.1 0.1` (역 층화 5겹 x 시드 3 + LGBM B 0.1 + CatBoost 0.1, 약 40분)
- 성장률 보정: `python3 scripts/growth_check.py final out/final_kfold_only.npy feat_v5a/features_final.parquet` → gap(+0.0081)을 log 예측에 더함

## 환경
Python 3.13, lightgbm 4.7.0, pandas 3.0.5, numpy 2.5.3, scikit-learn 1.9.1, pyarrow 26.0.1, catboost(최종 혼합용). LightGBM 시드 42·43·44, 5겹 분할 시드 0·1·2.
